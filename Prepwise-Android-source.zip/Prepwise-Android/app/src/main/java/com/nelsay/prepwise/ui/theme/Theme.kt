package com.nelsay.prepwise.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.googlefonts.R as GoogleFontsR
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Prepwise keeps one calm brand accent and lets track colour act as a small contextual cue.
val PrepwiseTeal = Color(0xFF0A8F73)
val PrepwiseTealBright = Color(0xFF36D6AE)
val PrepwiseNavy = Color(0xFF14233A)
val Eco = Color(0xFF14956F)
val Plant = Color(0xFF7467C8)
val Gold = Color(0xFFB77713)

private val LightBackground = Color(0xFFF7F8F6)
private val LightSurface = Color(0xFFFFFFFF)
private val LightSurfaceAlt = Color(0xFFF0F3EF)
private val LightInk = Color(0xFF161B1E)
private val LightMuted = Color(0xFF626B70)
private val LightOutline = Color(0xFFDDE3DF)

private val DarkBackground = Color(0xFF0D1418)
private val DarkSurface = Color(0xFF121C21)
private val DarkSurfaceAlt = Color(0xFF18262C)
private val DarkInk = Color(0xFFF3F7F6)
private val DarkMuted = Color(0xFFABB8B6)
private val DarkOutline = Color(0xFF2B3B40)

private val lightColors = lightColorScheme(
    primary = PrepwiseTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDF4EC),
    onPrimaryContainer = Color(0xFF0A4E40),
    secondary = PrepwiseNavy,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE7EDF5),
    onSecondaryContainer = PrepwiseNavy,
    tertiary = Plant,
    background = LightBackground,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    surfaceVariant = LightSurfaceAlt,
    onSurfaceVariant = LightMuted,
    outline = LightOutline,
    outlineVariant = Color(0xFFE9EDEB),
    error = Color(0xFFBA1A1A)
)

private val darkColors = darkColorScheme(
    primary = PrepwiseTealBright,
    onPrimary = Color(0xFF00382E),
    primaryContainer = Color(0xFF123C33),
    onPrimaryContainer = Color(0xFFB9F3DF),
    secondary = Color(0xFFB8C7DE),
    onSecondary = Color(0xFF233349),
    secondaryContainer = Color(0xFF233249),
    onSecondaryContainer = Color(0xFFD7E3F5),
    tertiary = Color(0xFFC6BFFF),
    background = DarkBackground,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceAlt,
    onSurfaceVariant = DarkMuted,
    outline = DarkOutline,
    outlineVariant = Color(0xFF223137),
    error = Color(0xFFFFB4AB)
)

private val googleFontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = GoogleFontsR.array.com_google_android_gms_fonts_certs
)

private val interFont = GoogleFont("Inter")
private val poppinsFont = GoogleFont("Poppins")

val InterFamily = FontFamily(
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.Medium),
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.Bold)
)

val PoppinsFamily = FontFamily(
    Font(googleFont = poppinsFont, fontProvider = googleFontProvider, weight = FontWeight.Normal),
    Font(googleFont = poppinsFont, fontProvider = googleFontProvider, weight = FontWeight.Medium),
    Font(googleFont = poppinsFont, fontProvider = googleFontProvider, weight = FontWeight.SemiBold)
)

private val prepwiseTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 34.sp,
        lineHeight = 40.sp,
        letterSpacing = (-0.6).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.35).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.2).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    titleSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = PoppinsFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = PoppinsFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 21.sp
    ),
    bodySmall = TextStyle(
        fontFamily = PoppinsFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 17.sp
    ),
    labelLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.15.sp
    ),
    labelSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.35.sp
    )
)

@Composable
fun PrepwiseTheme(content: @Composable () -> Unit) {
    val darkTheme = isSystemInDarkTheme()
    val colors = if (darkTheme) darkColors else lightColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            window.navigationBarColor = colors.surface.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colors,
        typography = prepwiseTypography,
        content = content
    )
}
