package com.nelsay.prepwise.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nelsay.prepwise.PrepwiseViewModel
import com.nelsay.prepwise.R
import com.nelsay.prepwise.ai.CoachClient
import com.nelsay.prepwise.data.*
import com.nelsay.prepwise.ui.theme.*
import com.nelsay.prepwise.voice.SpeechInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable fun PrepwiseRoot(vm:PrepwiseViewModel){
    when {
        vm.learner.signedInEmail.isBlank() -> SignIn(vm)
        vm.learner.trackId.isBlank() -> Setup(vm)
        else -> AppShell(vm)
    }
}

@Composable private fun SignIn(vm:PrepwiseViewModel){
    Box(Modifier.fillMaxSize().padding(horizontal=28.dp,vertical=32.dp),contentAlignment=Alignment.Center){
        Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)){
            Image(
                painter=painterResource(R.drawable.prepwise_logo),
                contentDescription="Prepwise",
                contentScale=ContentScale.Fit,
                modifier=Modifier.fillMaxWidth(.82f).heightIn(max=108.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text("Plant research mastery",fontWeight=FontWeight.Bold,fontSize=30.sp)
            Text("Learn deeply. Practise realistically. Prove you are ready.",color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
            Button(onClick=vm::signIn,enabled=!vm.authBusy,modifier=Modifier.fillMaxWidth().height(54.dp)){ Icon(Icons.Default.AccountCircle,null); Spacer(Modifier.width(10.dp)); Text(if(vm.authBusy)"Signing in…" else "Continue with Google") }
            vm.authError?.let{ Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp) }
            Text("Google sign-in is the entry point. Your path and commitment are chosen immediately after authentication.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
        }
    }
}

@Composable private fun Setup(vm:PrepwiseViewModel){
    var track by remember{mutableStateOf("")}; var commitment by remember{mutableIntStateOf(30)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
        Image(
            painter=painterResource(R.drawable.prepwise_logo),
            contentDescription="Prepwise",
            contentScale=ContentScale.Fit,
            modifier=Modifier.width(164.dp).height(48.dp)
        )
        Text("Welcome ${vm.learner.displayName.ifBlank{"back"}}",fontSize=12.sp,color=Muted)
        Text("Choose your research path",fontSize=30.sp,fontWeight=FontWeight.Bold)
        Text("This changes the entire curriculum, simulations, timed quests and readiness criteria. Both paths begin gently and become progressively research-intensive.",color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
        PathChoice("ecology","Plant Ecology","Field ecology, vegetation science, community ecology, restoration, R, GIS and spatial reasoning.",Eco,track){track=it}
        PathChoice("physiology","Plant Physiology","Water relations, photosynthesis, nutrition, stress physiology, experimentation, R, genomics and functional analysis.",Plant,track){track=it}
        Text("Weekly commitment",fontWeight=FontWeight.SemiBold,fontSize=18.sp)
        Text("Choose a sustainable daily study target. Fast Track assessments let you prove existing knowledge instead of rereading it.",fontSize=13.sp,color=Muted)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf(15,30,45,60).forEach{m->FilterChip(selected=commitment==m,onClick={commitment=m},label={Text("$m min")})} }
        Button(onClick={vm.finishSetup(track,commitment)},enabled=track.isNotBlank(),modifier=Modifier.fillMaxWidth().height(52.dp)){Text("Start my path")}
    }
}
@Composable private fun PathChoice(id:String,title:String,desc:String,color:Color,selected:String,on:(String)->Unit){
    Surface(onClick={on(id)},shape=RoundedCornerShape(18.dp),border=BorderStroke(if(selected==id)2.dp else 1.dp,if(selected==id)color else MaterialTheme.colorScheme.outline),color=MaterialTheme.colorScheme.surface){Column(Modifier.padding(18.dp)){Text(title,fontSize=21.sp,fontWeight=FontWeight.Bold,color=color);Spacer(Modifier.height(6.dp));Text(desc,fontSize=13.sp)}}
}

enum class Tab(val label:String){Path("Path"),Lab("Lab"),Quests("Quests"),Progress("Progress"),Coach("Coach")}
@Composable private fun AppShell(vm:PrepwiseViewModel){
    var tab by remember{mutableStateOf(Tab.Path)}; var lesson by remember{mutableStateOf<Lesson?>(null)}; var sim by remember{mutableStateOf<Simulation?>(null)}; var quest by remember{mutableStateOf<Quest?>(null)}; var fast by remember{mutableStateOf<Module?>(null)}
    if(lesson!=null){LessonView(vm,lesson!!){lesson=null};return}
    if(sim!=null){SimulationRunner(vm,sim!!){sim=null};return}
    if(quest!=null){QuestRunner(vm,quest!!){quest=null};return}
    if(fast!=null){FastTrackRunner(vm,fast!!,{vm.fastTrack(fast!!);fast=null},{fast=null});return}
    Scaffold(bottomBar={NavigationBar{Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(when(t){Tab.Path->Icons.Default.Route;Tab.Lab->Icons.Default.Science;Tab.Quests->Icons.Default.Timer;Tab.Progress->Icons.Default.Insights;Tab.Coach->Icons.Default.Mic},null)},label={Text(t.label)})}}}){pad->
        Box(Modifier.padding(pad)){when(tab){Tab.Path->PathScreen(vm,{lesson=it},{fast=it});Tab.Lab->LabScreen(vm){sim=it};Tab.Quests->QuestList(vm){quest=it};Tab.Progress->ProgressScreen(vm);Tab.Coach->CoachScreen(vm)}}
    }
}

@Composable private fun Header(vm:PrepwiseViewModel,title:String,sub:String){ val track=vm.repo.curriculum.tracks.first{it.id==vm.learner.trackId}; Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Text(track.name.uppercase(),fontSize=10.sp,letterSpacing=1.5.sp,color=Color(android.graphics.Color.parseColor(track.accent)));Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text(sub,fontSize=13.sp,color=Muted)} }

@Composable private fun PathScreen(vm:PrepwiseViewModel,onLesson:(Lesson)->Unit,onFast:(Module)->Unit){
    val track=vm.repo.curriculum.tracks.first{it.id==vm.learner.trackId}; val total=track.modules.sumOf{it.lessons.size}; val done=vm.learner.completedLessons.count{d->track.modules.any{m->m.lessons.any{it.id==d}}}; val pct=if(total==0)0 else done*100/total
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp),contentPadding=PaddingValues(vertical=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Header(vm,"Your path","Progressive lessons, realistic practice and strict mastery gates.");Spacer(Modifier.height(12.dp));Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant){Column(Modifier.padding(18.dp)){Text("Continue",fontWeight=FontWeight.Bold);Text("$done of $total lessons demonstrated • $pct%",color=Muted);LinearProgressIndicator(pct/100f,Modifier.fillMaxWidth().padding(top=10.dp));Text("Daily commitment: ${vm.learner.commitmentMinutes} minutes",fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=8.dp))}}}
        items(track.modules,key={it.id}){m->ModuleAccordion(vm,m,onLesson,onFast)}
    }
}
@Composable private fun ModuleAccordion(vm:PrepwiseViewModel,m:Module,onLesson:(Lesson)->Unit,onFast:(Module)->Unit){ var open by remember{mutableStateOf(m.number==1)}; val completed=m.lessons.count{it.id in vm.learner.completedLessons}; Surface(shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline),color=MaterialTheme.colorScheme.surface){Column{Row(Modifier.fillMaxWidth().clickable{open=!open}.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${m.number.toString().padStart(2,'0')}  ${m.title}",fontWeight=FontWeight.Bold);Text("$completed/${m.lessons.size} mastered",fontSize=12.sp,color=Muted)};Icon(if(open)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null)};if(open){HorizontalDivider();Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(m.overview,fontSize=13.sp,color=Muted);OutlinedButton(onClick={onFast(m)}){Icon(Icons.Default.Bolt,null);Spacer(Modifier.width(6.dp));Text("Prove I know this • Fast Track")};m.lessons.forEach{l->Surface(onClick={onLesson(l)},shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(l.id in vm.learner.completedLessons)Icons.Default.CheckCircle else Icons.Default.PlayCircle,null,tint=if(l.id in vm.learner.completedLessons)Eco else Plant);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(l.title,fontWeight=FontWeight.SemiBold);Text("${l.estimatedMinutes} min • basics → application → proof",fontSize=11.sp,color=Muted)}}}}}}}}}

@Composable private fun LessonView(vm:PrepwiseViewModel,l:Lesson,onBack:()->Unit){ val ctx=LocalContext.current; val sources=l.sourceIds.mapNotNull{vm.repo.sources[it]}; var answer by remember{mutableStateOf("")}; Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text(" Path")};Text(l.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("${l.estimatedMinutes} min",fontSize=12.sp,color=Muted);Section("Start here",l.intro);Section("Build the concept",l.body);Section("Worked research example",l.workedExample);Section("Practice",l.practicePrompt);OutlinedTextField(answer,{answer=it},Modifier.fillMaxWidth(),minLines=4,label={Text("Your reasoning")});VoiceButton(onText={answer=it});Section("Mastery gate",l.masteryPrompt);Text("Verified sources",fontWeight=FontWeight.Bold);sources.forEach{s->AssistChip(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(s.url)))},label={Text("${s.publisher} • ${s.title}")},leadingIcon={Icon(Icons.Default.Verified,null)})};l.videoUrl?.let{Button(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(it)))}){Icon(Icons.Default.SmartDisplay,null);Spacer(Modifier.width(6.dp));Text("Open vetted video / training resource")}};Button(onClick={vm.completeLesson(l.id)},modifier=Modifier.fillMaxWidth()){Text("Mark mastery demonstrated")};Spacer(Modifier.height(20.dp))}}
@Composable private fun Section(title:String,text:String){Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surface){Column(Modifier.padding(16.dp)){Text(title.uppercase(),fontSize=10.sp,letterSpacing=1.3.sp,color=Muted,fontWeight=FontWeight.Bold);Spacer(Modifier.height(7.dp));Text(text,lineHeight=21.sp)}}}

@Composable private fun LabScreen(vm:PrepwiseViewModel,onSim:(Simulation)->Unit){val sims=vm.repo.simulations.filter{it.trackId==vm.learner.trackId};LazyColumn(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header(vm,"Simulation lab","Synthetic training data, realistic decisions, real research logic.")};items(sims){s->Surface(onClick={onSim(s)},shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline)){Column(Modifier.padding(16.dp)){Text(s.title,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(s.setting,fontSize=12.sp,color=Muted);Text("Mission: ${s.mission}",fontSize=13.sp,modifier=Modifier.padding(top=8.dp));vm.learner.simulationScores[s.id]?.let{Text("Best score: $it%",color=Eco,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}}}}
@Composable private fun SimulationRunner(vm:PrepwiseViewModel,s:Simulation,onBack:()->Unit){val answers=remember{mutableStateMapOf<Int,Int>()};var result by remember{mutableStateOf<Int?>(null)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text(" Lab")};Text(s.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Section("Setting",s.setting);Section("Mission",s.mission);s.decisions.forEachIndexed{i,d->Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surface){Column(Modifier.padding(14.dp)){Text(d.prompt,fontWeight=FontWeight.Bold);d.options.forEachIndexed{oi,o->Row(Modifier.fillMaxWidth().clickable{answers[i]=oi}.padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(answers[i]==oi,{answers[i]=oi});Text(o)}}}}};Text("Field / instrument data",fontWeight=FontWeight.Bold);s.data.forEachIndexed{i,row->Row(Modifier.fillMaxWidth().background(if(i==0)MaterialTheme.colorScheme.surfaceVariant else Color.Transparent).padding(7.dp)){row.forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,fontWeight=if(i==0)FontWeight.Bold else FontWeight.Normal)}}};Button(onClick={val correct=s.decisions.indices.count{answers[it]==s.decisions[it].correct};result=correct*100/s.decisions.size;vm.scoreSimulation(s.id,result!!)},enabled=answers.size==s.decisions.size,modifier=Modifier.fillMaxWidth()){Text("Submit decisions")};result?.let{Text("Score: $it%",fontSize=24.sp,fontWeight=FontWeight.Bold,color=if(it>=80)Eco else Gold);Section("Debrief",s.debrief)}}}

@Composable private fun QuestList(vm:PrepwiseViewModel,onQuest:(Quest)->Unit){val qs=vm.repo.quests.filter{it.trackId==vm.learner.trackId};LazyColumn(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header(vm,"Timed quests","Apply science under pressure. These are scenario tasks, not trivia streaks.")};items(qs){q->Surface(onClick={onQuest(q)},shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Timer,null,tint=Gold);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(q.title,fontWeight=FontWeight.Bold);Text("${q.minutes} min • ${q.difficulty}",fontSize=12.sp,color=Muted);vm.learner.questScores[q.id]?.let{Text("Best: $it%",fontSize=12.sp,color=Eco)}}}}}}}
@Composable private fun QuestRunner(vm:PrepwiseViewModel,q:Quest,onBack:()->Unit){val scope=rememberCoroutineScope();val grader=remember{CoachClient()};var remaining by remember{mutableIntStateOf(q.minutes*60)};var started by remember{mutableStateOf(false)};var answer by remember{mutableStateOf("")};var feedback by remember{mutableStateOf("")};var score by remember{mutableStateOf<Int?>(null)};var busy by remember{mutableStateOf(false)};LaunchedEffect(started){while(started&&remaining>0){delay(1000);remaining--}};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text(" Quests")};Text(q.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text(String.format("%02d:%02d",remaining/60,remaining%60),fontSize=30.sp,fontWeight=FontWeight.Bold,color=if(remaining<60)MaterialTheme.colorScheme.error else Gold);Section("Brief",q.brief);Text("Deliverables",fontWeight=FontWeight.Bold);q.tasks.forEach{Text("• $it")};if(!started)Button(onClick={started=true},modifier=Modifier.fillMaxWidth()){Text("Start timer")};OutlinedTextField(answer,{answer=it},Modifier.fillMaxWidth(),minLines=7,label={Text("Your response")});VoiceButton(onText={answer=it});Button(onClick={started=false;busy=true;scope.launch{grader.grade(answer,q.answerGuide,q.brief+" Deliverables: "+q.tasks.joinToString()).onSuccess{score=it.score.coerceIn(0,100);feedback=it.feedback+(if(it.missing.isNotEmpty())"\nMissing: "+it.missing.joinToString() else "");vm.scoreQuest(q.id,score!!)}.onFailure{feedback=it.message.orEmpty()};busy=false}},enabled=answer.length>40&&!busy,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Grading against verified rubric…" else "Finish & grade")};score?.let{Text("Score: $it%",fontSize=26.sp,fontWeight=FontWeight.Bold,color=if(it>=80)Eco else Gold)};if(feedback.isNotBlank())Section("Rubric feedback",feedback);if(score!=null)Section("Verified answer guide",q.answerGuide)}}

@Composable private fun FastTrackRunner(vm:PrepwiseViewModel,m:Module,onPass:()->Unit,onBack:()->Unit){var idx by remember{mutableIntStateOf(0)};var score by remember{mutableIntStateOf(0)};var done by remember{mutableStateOf(false)};val lessons=m.lessons;val current=lessons.getOrNull(idx);Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text(" Path")};Text("Fast Track • ${m.title}",fontSize=27.sp,fontWeight=FontWeight.Bold);Text("You must recognize the underlying concept across novel research scenarios. 100% is required to skip the module; otherwise the app returns you to the lesson path.",color=Muted);if(!done&&current!=null){Section("Scenario ${idx+1}/${lessons.size}",current.workedExample);lessons.shuffled().forEach{opt->OutlinedButton(onClick={if(opt.id==current.id)score++;idx++;if(idx>=lessons.size)done=true},modifier=Modifier.fillMaxWidth()){Text(opt.title)}}}else{Text("$score / ${lessons.size}",fontSize=34.sp,fontWeight=FontWeight.Bold);if(score==lessons.size)Button(onClick=onPass,modifier=Modifier.fillMaxWidth()){Text("Fast Track passed • mark module mastered")}else{Text("Not passed. This is useful evidence of where deeper study will help.",color=Gold);Button(onClick=onBack){Text("Return to lessons")}}}}}

@Composable private fun ProgressScreen(vm:PrepwiseViewModel){val track=vm.repo.curriculum.tracks.first{it.id==vm.learner.trackId};val lessons=track.modules.flatMap{it.lessons};val lPct=(vm.learner.completedLessons.count{it in lessons.map{l->l.id}}*100/(lessons.size.coerceAtLeast(1)));val sims=vm.repo.simulations.filter{it.trackId==track.id};val simPct=if(sims.isEmpty())0 else sims.map{vm.learner.simulationScores[it.id]?:0}.average().toInt();val qs=vm.repo.quests.filter{it.trackId==track.id};val qPct=if(qs.isEmpty())0 else qs.map{vm.learner.questScores[it.id]?:0}.average().toInt();val readiness=(lPct*.60+simPct*.25+qPct*.15).toInt();LazyColumn(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header(vm,"Readiness","You become certification-ready by demonstrating competence, not opening pages.");Metric("Course mastery",lPct);Metric("Simulation performance",simPct);Metric("Timed quest performance",qPct);Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant){Column(Modifier.padding(18.dp)){Text(if(readiness>=85)"READY FOR CERTIFICATION" else "CERTIFICATION READINESS",fontSize=11.sp,letterSpacing=1.4.sp,color=if(readiness>=85)Eco else Gold,fontWeight=FontWeight.Bold);Text("$readiness%",fontSize=44.sp,fontWeight=FontWeight.Bold);Text(if(readiness>=85)"Your current evidence meets Prepwise's internal readiness threshold. Official providers still determine their own requirements." else "Target ≥85% with strong simulation and timed performance.",fontSize=13.sp,color=Muted)}};Text("Source Lock",fontSize=21.sp,fontWeight=FontWeight.Bold);Text("Every curriculum module links back to the approved source registry. AI explanations are secondary and must remain inside the verified context.",color=Muted);vm.repo.sources.values.forEach{s->Text("✓ ${s.publisher} — ${s.title}",fontSize=12.sp)}}}}
@Composable private fun Metric(name:String,v:Int){Surface(shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Row{Text(name,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Text("$v%")};LinearProgressIndicator(v/100f,Modifier.fillMaxWidth().padding(top=8.dp))}}}

@Composable private fun CoachScreen(vm:PrepwiseViewModel){val scope=rememberCoroutineScope();val client=remember{CoachClient()};var mode by remember{mutableStateOf("Coach")};var q by remember{mutableStateOf("")};var reply by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Header(vm,"Side coach","Ask, speak, debug or defend—but verified course content remains the source of truth.");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Tutor","Coach","Socratic","Examiner").forEach{FilterChip(selected=mode==it,onClick={mode=it},label={Text(it)})}};Text("Source Lock rule",fontWeight=FontWeight.Bold);Text("The coach receives approved lesson/source context. If that context cannot support an answer, the server prompt instructs it to say so instead of inventing a scientific claim.",fontSize=13.sp,color=Muted);OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),minLines=5,label={Text("Ask or answer aloud")});VoiceButton(onText={q=it;vm.addViva()});Button(onClick={scope.launch{busy=true;val track=vm.repo.curriculum.tracks.first{it.id==vm.learner.trackId};val current=track.modules.flatMap{it.lessons}.firstOrNull{it.id !in vm.learner.completedLessons}?:track.modules.last().lessons.last();val src=current.sourceIds.mapNotNull{vm.repo.sources[it]};client.ask(q,mode,current,src).onSuccess{reply=it.answer+(if(it.citations.isNotEmpty())"\n\nSources: ${it.citations.joinToString()}" else "")}.onFailure{reply=it.message.orEmpty()};busy=false}},enabled=q.isNotBlank()&&!busy,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Checking verified context…" else "Ask coach")};if(reply.isNotBlank())Section("Coach response",reply)}}

@Composable private fun VoiceButton(onText:(String)->Unit){val ctx=LocalContext.current;val speech=remember{SpeechInput(ctx)};val perm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->if(ok)speech.start(onText){Toast.makeText(ctx,it,Toast.LENGTH_SHORT).show()}};OutlinedButton(onClick={perm.launch(Manifest.permission.RECORD_AUDIO)}){Icon(Icons.Default.Mic,null);Spacer(Modifier.width(6.dp));Text("Speak into app")}}
