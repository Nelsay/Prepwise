# Build status

## Completed
- Native Kotlin/Jetpack Compose project structure.
- Full onboarding flow and two paths.
- 31 modules / 124 populated lessons.
- Accordion curriculum and Fast Track.
- Six realistic scored simulations with synthetic datasets.
- Twelve timed scientific quests.
- Voice input and viva counter.
- AI Source Lock coach client and secure server proxy.
- Server-side rubric grading for timed quests.
- Progress persistence and certification-readiness calculation.
- Source registry and vetted-resource buttons.
- GitHub Actions APK workflow.

## Requires user-owned credentials before runtime authentication/AI can work
- Firebase Android project values and Google OAuth web client ID.
- Deployed HTTPS coach proxy with an OpenAI API key stored on the server.

## Scientific QA status
The lesson architecture and source families are grounded, but the 124 lesson texts have not yet received a human line-by-line scientific editorial verification pass. Do not describe the corpus as publication-grade until that pass is completed.

## Firebase + update signing refresh
- Bundled the supplied Firebase config as `app/google-services.json`.
- Package confirmed as `com.nelsay.prepwise`.
- Google Services Gradle plugin enabled.
- Firebase Auth now reads the generated `default_web_client_id` from the bundled config.
- Fixed update keystore included at `signing/prepwise-update.jks`.
- Debug and release APKs use the same update certificate.
- Automatic monotonic versionCode added for future in-place APK updates.

## 2026-09-08 GitHub build fix
The uploaded GitHub log failed at `:app:compileReleaseKotlin` because Firebase Auth 24.2.0 contains Kotlin metadata 2.3.0 while the project used Kotlin 2.0.21. The Kotlin Android, Compose, and Serialization plugins are now aligned at 2.3.20. The existing Firebase configuration, package name, and Prepwise update signing certificate are unchanged.

## 2026-09-08 Kotlin 2.3 Gradle DSL compatibility fix
- Replaced the removed `kotlinOptions { jvmTarget = "17" }` syntax with Kotlin 2.3's `compilerOptions` DSL.
- JVM target remains Java 17.
- Firebase package, google-services configuration, Prepwise signing key, SHA fingerprints, and application ID are unchanged.
