# Prepwise build status

UI/UX correction applied after the latest GitHub compile log.

Known compiler issue from GitHub (`themeMode`/`accent` JVM setter collision) is fixed by `updateThemeMode` and `updateAccent`.

Current source also includes:
- Android BackHandler navigation
- status/navigation bar safe insets
- compact four-tab shell
- calm progressive Home
- consolidated Practice hub
- compact Settings
- OpenAI + Gemini provider settings
- permanent Prepwise update signing key
- Firebase Google Sign-In configuration

The GitHub Actions workflow remains the authoritative Android compile/sign test.
