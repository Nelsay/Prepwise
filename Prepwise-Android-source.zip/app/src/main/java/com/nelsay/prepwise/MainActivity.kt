package com.nelsay.prepwise

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nelsay.prepwise.ai.CoachClient
import com.nelsay.prepwise.auth.GoogleAuthManager
import com.nelsay.prepwise.data.CurriculumRepository
import com.nelsay.prepwise.data.LearnerState
import com.nelsay.prepwise.data.Module
import com.nelsay.prepwise.data.ProgressStore
import com.nelsay.prepwise.ui.screens.PrepwiseRoot
import com.nelsay.prepwise.ui.theme.PrepwiseAccent
import com.nelsay.prepwise.ui.theme.PrepwiseTheme
import com.nelsay.prepwise.ui.theme.PrepwiseThemeMode
import com.nelsay.prepwise.ui.theme.ThemePreferences
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class PrepwiseViewModel(app: Application) : AndroidViewModel(app) {
    val repo = CurriculumRepository(app)
    val ai = CoachClient(app)

    private val store = ProgressStore(app)
    private val auth = GoogleAuthManager(app)
    private val themePreferences = ThemePreferences(app)

    var learner by mutableStateOf(LearnerState())
        private set
    var authBusy by mutableStateOf(false)
        private set
    var authError by mutableStateOf<String?>(null)
        private set

    var themeMode by mutableStateOf(themePreferences.mode)
        private set
    var accent by mutableStateOf(themePreferences.accent)
        private set

    init {
        viewModelScope.launch {
            store.state.collectLatest { learner = it }
        }
    }

    private fun update(transform: (LearnerState) -> LearnerState) {
        learner = transform(learner)
        viewModelScope.launch { store.save(learner) }
    }

    fun signIn() {
        viewModelScope.launch {
            authBusy = true
            authError = null
            auth.signIn()
                .onSuccess { (email, name) ->
                    update { it.copy(signedInEmail = email, displayName = name) }
                }
                .onFailure { authError = it.message }
            authBusy = false
        }
    }

    fun logout() {
        auth.signOut()
        // Preserve this device's learning progress so signing back in does not force a reset.
        update { it.copy(signedInEmail = "", displayName = "") }
    }

    fun updateThemeMode(mode: PrepwiseThemeMode) {
        themePreferences.mode = mode
        themeMode = mode
    }

    fun updateAccent(value: PrepwiseAccent) {
        themePreferences.accent = value
        accent = value
    }

    fun finishSetup(track: String, minutes: Int) = update {
        it.copy(trackId = track, commitmentMinutes = minutes)
    }

    fun completeLesson(id: String, score: Int = 100) = update {
        it.copy(
            completedLessons = it.completedLessons + id,
            lessonScores = it.lessonScores + (id to score)
        )
    }

    fun fastTrack(module: Module) = update {
        it.copy(
            fastTrackedModules = it.fastTrackedModules + module.id,
            completedLessons = it.completedLessons + module.lessons.map { lesson -> lesson.id },
            lessonScores = it.lessonScores + module.lessons.associate { lesson -> lesson.id to 90 }
        )
    }

    fun scoreSimulation(id: String, score: Int) = update {
        it.copy(simulationScores = it.simulationScores + (id to score))
    }

    fun scoreQuest(id: String, score: Int) = update {
        it.copy(questScores = it.questScores + (id to score))
    }

    fun addViva() = update { it.copy(spokenVivas = it.spokenVivas + 1) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: PrepwiseViewModel = viewModel()
            PrepwiseTheme(mode = vm.themeMode, accent = vm.accent) {
                PrepwiseRoot(vm)
            }
        }
    }
}
