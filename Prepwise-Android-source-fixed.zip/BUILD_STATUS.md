# Prepwise build status — UI/settings correction

## Included
- Native Kotlin + Jetpack Compose Android project.
- Google Sign-In through Firebase Auth + Android Credential Manager.
- Post-sign-in path choice: Plant Ecology or Plant Physiology, then daily commitment.
- 31 modules / 124 populated lessons.
- Beginner-first lessons with progressive depth, worked examples, practice and mastery gates.
- Accordion/timeline learning path and Fast Track testing.
- Six research-style simulations using synthetic datasets.
- Twelve timed scientific quests.
- Android speech input for spoken answers and viva-style practice.
- Readiness/progress scoring.
- Source registry and Source Lock rules.
- Permanent Prepwise update signing key bundled in `signing/prepwise-update.jks`.
- Firebase configuration bundled in `app/google-services.json`.

## UI/UX correction
- Catalyst is the primary presentation guide.
- Inter headings + Poppins body copy.
- Dark-first theme by default with a true dark background across every Compose screen.
- No white simulation canvas when dark mode is selected.
- Raised surfaces remain dark and use high-contrast light text.
- Simulation answer options now have explicit borders and high-contrast selected/unselected states.
- Five bottom destinations: Path / Lab / Quests / Progress / More.
- More contains Side Coach and Settings, matching Catalyst's separation of supporting tools from the learning route.
- Theme mode is configurable: System / Light / Dark.
- Accent colour is configurable using the Prepwise logo palette.
- Settings includes account information and Log out.

## AI settings
- Provider selector includes exactly OpenAI and Gemini.
- User-supplied API keys are encrypted locally using Android Keystore.
- OpenAI default model: `gpt-5.6-luna` (editable in Settings).
- Gemini default model: `gemini-3.8-flash` (editable in Settings).
- Connection test is built into Settings.
- Source Lock remains active for either provider.
- The old optional HTTPS coach proxy is retained only as a fallback when `COACH_ENDPOINT` is supplied.

## Known GitHub build failures already corrected
1. Firebase Auth 24.2.0 was compiled with Kotlin metadata 2.3.0 while Prepwise used Kotlin 2.0.21. Prepwise now uses Kotlin 2.3.20.
2. Kotlin 2.3 rejected `kotlinOptions { jvmTarget = "17" }`. Prepwise now uses the `compilerOptions` DSL with `JvmTarget.JVM_17`.
3. The downloadable-font provider used an invalid `array` reference. Prepwise now uses `R.array.com_google_android_gms_fonts_certs` and bundles `font_certs.xml`.

No newer GitHub build log was supplied after failure #3, so there is no fourth confirmed compiler error in the evidence available here. The separate workflow now contains explicit preflight checks for all three prior failures plus the new Settings/AI/theme requirements before it runs Gradle.

## Scientific QA status
The curriculum architecture is source-linked, but the 124 lesson texts still require a formal human line-by-line scientific editorial review before the corpus should be described as publication-grade. AI responses are not promoted into trusted curriculum content automatically.

## Additional regression fixed during final static QA
While wiring the new provider settings, one quest screen still attempted to construct `CoachClient()` without the required Android `Context`. That would have become the next Kotlin compile failure after the earlier font fix. Quest grading now reuses the ViewModel-owned `vm.ai` client, the same provider/key configuration used by Side Coach and Settings.
