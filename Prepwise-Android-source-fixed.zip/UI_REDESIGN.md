# Prepwise UI/UX presentation system

## Design source principles

Prepwise's presentation is intentionally based on the strongest patterns from the user's Catalyst and Bera apps without copying their content.

### From Catalyst
- restrained Material 3
- one primary accent
- strong whitespace
- progress bars/rings
- timeline/progression layouts instead of repeated card grids
- mastery-first progression

### From Bera
- progressive disclosure
- current task is the visual hero
- spacious challenge screens
- completed content gets out of the way
- focused timed work without dashboard clutter

## Prepwise rules

1. Screen horizontal padding: 20dp.
2. Readable content width: max 760dp on tablets/landscape.
3. Inter: display, heading, title and labels.
4. Poppins: lesson copy, descriptions, explanations and inputs.
5. Do not nest cards inside cards.
6. At most one dominant hero surface per main tab.
7. Group small metrics into a single strip.
8. Current module opens by default; other modules remain compact.
9. Lesson content uses typography and whitespace first; surfaces only for worked examples, practice/mastery and verified-context notices.
10. Simulations and Fast Track show one decision at a time.
11. Dark/light themes use proper foreground contrast, not inverted colors.
