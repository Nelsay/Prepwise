package com.nelsay.prepwise.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Bundle

class SpeechInput(private val context:Context) {
    private var recognizer:SpeechRecognizer?=null
    fun start(onText:(String)->Unit,onError:(String)->Unit) {
        stop()
        val useOnDevice=Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        recognizer=if(useOnDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(object:RecognitionListener{
            override fun onResults(results:Bundle?) { onText(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
            override fun onError(error:Int) { onError("Speech recognition error $error") }
            override fun onReadyForSpeech(params:Bundle?){}; override fun onBeginningOfSpeech(){}; override fun onRmsChanged(rmsdB:Float){}; override fun onBufferReceived(buffer:ByteArray?){}; override fun onEndOfSpeech(){}; override fun onPartialResults(partialResults:Bundle?){}; override fun onEvent(eventType:Int,params:Bundle?){}
        })
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false) }
        recognizer?.startListening(i)
    }
    fun stop(){ recognizer?.destroy(); recognizer=null }
}
