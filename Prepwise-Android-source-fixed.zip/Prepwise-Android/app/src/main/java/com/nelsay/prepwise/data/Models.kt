package com.nelsay.prepwise.data

import kotlinx.serialization.Serializable

@Serializable data class SourceRef(val id:String,val title:String,val publisher:String,val url:String,val type:String)
@Serializable data class Lesson(val id:String,val number:Int,val title:String,val estimatedMinutes:Int,val intro:String,val body:String,val workedExample:String,val practicePrompt:String,val masteryPrompt:String,val sourceIds:List<String>,val videoUrl:String?=null)
@Serializable data class Module(val id:String,val number:Int,val title:String,val overview:String,val sourceIds:List<String>,val lessons:List<Lesson>)
@Serializable data class Track(val id:String,val name:String,val accent:String,val description:String,val modules:List<Module>)
@Serializable data class Curriculum(val tracks:List<Track>)
@Serializable data class Quest(val id:String,val trackId:String,val title:String,val minutes:Int,val difficulty:String,val brief:String,val tasks:List<String>,val answerGuide:String)
@Serializable data class QuestPack(val quests:List<Quest>)
@Serializable data class SimulationDecision(val prompt:String,val options:List<String>,val correct:Int)
@Serializable data class Simulation(val id:String,val trackId:String,val title:String,val setting:String,val mission:String,val decisions:List<SimulationDecision>,val data:List<List<String>>,val debrief:String)
@Serializable data class SimulationPack(val simulations:List<Simulation>)

@Serializable
data class LearnerState(
    val signedInEmail:String="",
    val displayName:String="",
    val trackId:String="",
    val commitmentMinutes:Int=30,
    val completedLessons:Set<String> = emptySet(),
    val fastTrackedModules:Set<String> = emptySet(),
    val lessonScores:Map<String,Int> = emptyMap(),
    val questScores:Map<String,Int> = emptyMap(),
    val simulationScores:Map<String,Int> = emptyMap(),
    val spokenVivas:Int = 0
)
