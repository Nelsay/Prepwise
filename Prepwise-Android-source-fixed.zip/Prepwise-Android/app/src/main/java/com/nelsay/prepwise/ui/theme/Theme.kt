package com.nelsay.prepwise.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg=Color(0xFF0F1117); val Surface=Color(0xFF181C27); val Surface2=Color(0xFF1E2333); val Border=Color(0xFF2A3048)
val Text=Color(0xFFD8DCE8); val Muted=Color(0xFF7F89A6); val Eco=Color(0xFF3ECF8E); val Plant=Color(0xFFA78BFA); val Gold=Color(0xFFF5C842)
private val dark=darkColorScheme(background=Bg,surface=Surface,surfaceVariant=Surface2,primary=Plant,secondary=Eco,onBackground=Text,onSurface=Text,outline=Border)
private val light=lightColorScheme(primary=Color(0xFF7158D9),secondary=Color(0xFF187D59),background=Color(0xFFF7F7FA),surface=Color.White,onBackground=Color(0xFF171922),onSurface=Color(0xFF171922),outline=Color(0xFFE0E2EA))
@Composable fun PrepwiseTheme(content: @Composable () -> Unit){ MaterialTheme(colorScheme=if(isSystemInDarkTheme()) dark else light,typography=Typography(),content=content) }
