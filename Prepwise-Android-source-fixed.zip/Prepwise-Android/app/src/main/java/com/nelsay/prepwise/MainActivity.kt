package com.nelsay.prepwise

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nelsay.prepwise.auth.GoogleAuthManager
import com.nelsay.prepwise.data.*
import com.nelsay.prepwise.ui.screens.PrepwiseRoot
import com.nelsay.prepwise.ui.theme.PrepwiseTheme
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class PrepwiseViewModel(app:Application):AndroidViewModel(app){
    val repo=CurriculumRepository(app)
    private val store=ProgressStore(app)
    private val auth=GoogleAuthManager(app)
    var learner by mutableStateOf(LearnerState()); private set
    var authBusy by mutableStateOf(false); private set
    var authError by mutableStateOf<String?>(null); private set
    init { viewModelScope.launch { store.state.collectLatest { learner=it } } }
    private fun update(f:(LearnerState)->LearnerState){ learner=f(learner); viewModelScope.launch{store.save(learner)} }
    fun signIn(){ viewModelScope.launch { authBusy=true; authError=null; auth.signIn().onSuccess{(e,n)->update{it.copy(signedInEmail=e,displayName=n)}}.onFailure{authError=it.message}; authBusy=false } }
    fun finishSetup(track:String,minutes:Int)=update{it.copy(trackId=track,commitmentMinutes=minutes)}
    fun completeLesson(id:String,score:Int=100)=update{it.copy(completedLessons=it.completedLessons+id,lessonScores=it.lessonScores+(id to score))}
    fun fastTrack(module:Module)=update{it.copy(fastTrackedModules=it.fastTrackedModules+module.id,completedLessons=it.completedLessons+module.lessons.map{l->l.id},lessonScores=it.lessonScores+module.lessons.associate{l->l.id to 90})}
    fun scoreSimulation(id:String,score:Int)=update{it.copy(simulationScores=it.simulationScores+(id to score))}
    fun scoreQuest(id:String,score:Int)=update{it.copy(questScores=it.questScores+(id to score))}
    fun addViva()=update{it.copy(spokenVivas=it.spokenVivas+1)}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); setContent { PrepwiseTheme { val vm:PrepwiseViewModel= viewModel(); PrepwiseRoot(vm) } } }
}
