package com.nelsay.prepwise.ai

import com.nelsay.prepwise.BuildConfig
import com.nelsay.prepwise.data.Lesson
import com.nelsay.prepwise.data.SourceRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable data class CoachPayload(val question:String,val mode:String,val lessonTitle:String,val verifiedContext:String,val sourceUrls:List<String>)
@Serializable data class CoachReply(val answer:String,val citations:List<String> = emptyList())
@Serializable data class GradePayload(val response:String,val rubric:String,val task:String)
@Serializable data class GradeReply(val score:Int,val feedback:String,val missing:List<String> = emptyList())

class CoachClient {
    private val http=OkHttpClient()
    private val json=Json { ignoreUnknownKeys=true }
    suspend fun grade(response:String,rubric:String,task:String):Result<GradeReply> = withContext(Dispatchers.IO) {
        runCatching {
            require(BuildConfig.COACH_ENDPOINT.isNotBlank()) { "AI grading endpoint is not configured; this timed quest cannot count toward readiness yet." }
            val payload=GradePayload(response,rubric,task)
            val req=Request.Builder().url(BuildConfig.COACH_ENDPOINT.trimEnd('/')+"/grade").post(json.encodeToString(GradePayload.serializer(),payload).toRequestBody("application/json".toMediaType())).build()
            http.newCall(req).execute().use { r ->
                if(!r.isSuccessful) error("Grading server returned ${r.code}")
                json.decodeFromString<GradeReply>(r.body?.string().orEmpty())
            }
        }
    }

    suspend fun ask(question:String,mode:String,lesson:Lesson?,sources:List<SourceRef>):Result<CoachReply> = withContext(Dispatchers.IO) {
        runCatching {
            require(BuildConfig.COACH_ENDPOINT.isNotBlank()) { "AI coach endpoint is not configured. Verified lesson content remains available offline." }
            val contextText=lesson?.let { "${it.intro}\n${it.body}\nWorked example: ${it.workedExample}\nPractice: ${it.practicePrompt}" }.orEmpty()
            val payload=CoachPayload(question,mode,lesson?.title ?: "General track coaching",contextText,sources.map{it.url})
            val req=Request.Builder().url(BuildConfig.COACH_ENDPOINT.trimEnd('/')+"/coach").post(json.encodeToString(CoachPayload.serializer(),payload).toRequestBody("application/json".toMediaType())).build()
            http.newCall(req).execute().use { r ->
                if(!r.isSuccessful) error("Coach server returned ${r.code}")
                json.decodeFromString<CoachReply>(r.body?.string().orEmpty())
            }
        }
    }
}
