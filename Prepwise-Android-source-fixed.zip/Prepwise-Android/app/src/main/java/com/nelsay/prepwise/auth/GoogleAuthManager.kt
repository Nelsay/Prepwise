package com.nelsay.prepwise.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.nelsay.prepwise.R
import kotlinx.coroutines.tasks.await

class GoogleAuthManager(private val context: Context) {
    private fun auth(): FirebaseAuth {
        // google-services.json + the Google Services Gradle plugin initialize
        // the default Firebase app automatically. This explicit check produces a
        // useful error if the project file is ever accidentally removed.
        check(FirebaseApp.getApps(context).isNotEmpty()) {
            "Firebase is not initialized. Keep app/google-services.json in the Prepwise source."
        }
        return FirebaseAuth.getInstance()
    }

    suspend fun signIn(): Result<Pair<String, String>> = runCatching {
        val webClientId = context.getString(R.string.default_web_client_id)
        require(webClientId.isNotBlank()) {
            "Google Web Client ID is missing from the Firebase configuration."
        }

        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(option)
            .build()

        val result = CredentialManager.create(context)
            .getCredential(context, request)

        val custom = result.credential as? CustomCredential
            ?: error("Google credential was not returned")

        require(custom.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "Unexpected credential type"
        }

        val token = GoogleIdTokenCredential.createFrom(custom.data)
        val firebaseCredential = GoogleAuthProvider.getCredential(token.idToken, null)
        val user = auth().signInWithCredential(firebaseCredential).await().user
            ?: error("Firebase sign-in did not return a user")

        (user.email ?: "") to (user.displayName ?: token.displayName ?: "Learner")
    }
}
