package com.nelsay.prepwise.data

import android.content.Context
import kotlinx.serialization.json.Json

class CurriculumRepository(private val context:Context) {
    private val json = Json { ignoreUnknownKeys = true }
    val curriculum: Curriculum by lazy { json.decodeFromString(read("curriculum.json")) }
    val quests: List<Quest> by lazy { json.decodeFromString<QuestPack>(read("quests.json")).quests }
    val simulations: List<Simulation> by lazy { json.decodeFromString<SimulationPack>(read("simulations.json")).simulations }
    val sources: Map<String,SourceRef> by lazy { json.decodeFromString<List<SourceRef>>(read("sources.json")).associateBy { it.id } }
    private fun read(name:String)=context.assets.open(name).bufferedReader().use { it.readText() }
}
