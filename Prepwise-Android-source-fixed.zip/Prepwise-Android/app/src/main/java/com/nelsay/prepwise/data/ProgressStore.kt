package com.nelsay.prepwise.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore("prepwise_progress")
class ProgressStore(private val context:Context) {
    private val key=stringPreferencesKey("learner_state")
    private val json=Json { ignoreUnknownKeys=true; encodeDefaults=true }
    val state: Flow<LearnerState> = context.dataStore.data.map { p -> p[key]?.let { runCatching { json.decodeFromString<LearnerState>(it) }.getOrNull() } ?: LearnerState() }
    suspend fun save(s:LearnerState)=context.dataStore.edit { it[key]=json.encodeToString(LearnerState.serializer(),s) }
}
