import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "1mb" }));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-5.6-terra";

function parseJson(text) {
  const cleaned = text.trim().replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
  return JSON.parse(cleaned);
}

app.get("/health", (_, res) => res.json({ ok: true, model }));

app.post("/coach", async (req, res) => {
  try {
    const { question = "", mode = "Coach", lessonTitle = "", verifiedContext = "", sourceUrls = [] } = req.body || {};
    if (!question.trim()) return res.status(400).json({ error: "question required" });
    const instructions = `You are Prepwise's ${mode} for plant-science learning. SOURCE LOCK IS ABSOLUTE.\n` +
      `You may explain, simplify, ask Socratic questions, or critique reasoning ONLY using the VERIFIED CONTEXT supplied below. ` +
      `Do not add scientific facts from memory. If the context does not support the answer, say exactly: "I cannot verify that from the approved lesson sources yet." ` +
      `Never invent citations. Citations may only be selected from SOURCE URLS. Keep explanations rigorous but beginner-friendly. ` +
      `Return strict JSON: {"answer":"...","citations":["..."]}.`;
    const input = `LESSON: ${lessonTitle}\n\nVERIFIED CONTEXT:\n${verifiedContext}\n\nSOURCE URLS:\n${sourceUrls.join("\n")}\n\nLEARNER:\n${question}`;
    const response = await client.responses.create({ model, instructions, input, store: false });
    const parsed = parseJson(response.output_text);
    const allowed = new Set(sourceUrls);
    const citations = Array.isArray(parsed.citations) ? parsed.citations.filter(x => allowed.has(x)) : [];
    res.json({ answer: String(parsed.answer || ""), citations });
  } catch (e) {
    res.status(500).json({ error: e?.message || "coach failed" });
  }
});

app.post("/grade", async (req, res) => {
  try {
    const { response = "", rubric = "", task = "" } = req.body || {};
    if (!response.trim() || !rubric.trim()) return res.status(400).json({ error: "response and rubric required" });
    const instructions = `You are a strict scientific-assessment grader. Grade ONLY against the supplied VERIFIED RUBRIC. ` +
      `Do not reward plausible facts that are absent from the rubric, and do not add new scientific claims. ` +
      `Score 0-100 for correctness, coverage, reasoning and explicit assumptions. A fluent but incorrect answer must score poorly. ` +
      `Return strict JSON only: {"score":0,"feedback":"specific evidence-based feedback","missing":["criterion"]}.`;
    const input = `TASK:\n${task}\n\nVERIFIED RUBRIC:\n${rubric}\n\nLEARNER RESPONSE:\n${response}`;
    const out = await client.responses.create({ model, instructions, input, store: false });
    const parsed = parseJson(out.output_text);
    res.json({ score: Math.max(0, Math.min(100, Number(parsed.score) || 0)), feedback: String(parsed.feedback || ""), missing: Array.isArray(parsed.missing) ? parsed.missing.map(String) : [] });
  } catch (e) {
    res.status(500).json({ error: e?.message || "grading failed" });
  }
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`Prepwise coach proxy on :${port}`));
