# Prepwise — Plant Research Mastery (Android)

Prepwise is a native Android mastery app for two postgraduate-preparation routes: **Plant Ecology** and **Plant Physiology**. The goal is competence first: learn from approachable foundations, apply the concept in realistic scenarios, pass strict mastery gates, and reach an internal **Ready for Certification** threshold before pursuing external credentials.

## Implemented in this build

- Google sign-in entry flow using Android Credential Manager + Firebase Auth.
- Post-sign-in onboarding: choose **Plant Ecology** or **Plant Physiology**, choose 15/30/45/60-minute commitment, submit, then enter dashboard.
- NamingLab-inspired fixed bottom-tab shell: Path / Lab / Quests / Progress / Coach.
- Dark/light Material 3 theme with deep navy surfaces, ecology green and plant-physiology violet accents.
- Catalyst-style accordion course path with progressive disclosure.
- **31 modules / 124 lessons** seeded in `assets/curriculum.json`.
- Lessons use full explanations rather than label-only text: Start Here → Build the Concept → Worked Research Example → Practice → Mastery Gate → Verified Sources.
- Fast Track on every module. It uses scenario-to-concept transfer questions; 100% is required to skip the module.
- Realistic simulation engine with synthetic research datasets and decision scoring.
- Ecology simulations: vegetation sampling, restoration diagnosis, GIS habitat suitability.
- Physiology simulations: drought physiology, salinity mechanisms, RNA-seq-to-physiology inference.
- Timed scientific quests with free-response reasoning. They require server-side rubric grading before they count toward readiness.
- Android speech recognition for answers and viva-style practice; on-device recognition is preferred where Android supports it.
- AI Coach modes: Tutor / Coach / Socratic / Examiner.
- Source Lock: AI receives only the approved lesson context and allowed source URLs; unsupported questions must return that they cannot be verified from the approved context.
- Secure AI architecture: the OpenAI key is **never stored in the APK**. `coach-proxy/` is a server-side proxy using the OpenAI Responses API.
- Readiness score combines course completion, simulation results, and timed-quest performance; threshold is 85%.
- Local progress persistence through DataStore.
- Official source registry currently includes ESA, SER, QGIS, NCBI/NLM, EMBL-EBI and Ensembl resources.
- GitHub Actions workflow builds a debug APK after project credentials are added as repository secrets.

## Curriculum size

- Plant Ecology: 15 modules, 60 lessons.
- Plant Physiology: 16 modules, 64 lessons.
- Total: 31 modules, 124 lessons.

The physiology route includes advanced molecular/genomic physiology, BLAST reasoning, transcriptomics, functional analysis and gene-editing concepts so the route still supports a later genetics-oriented MSc direction without making the onboarding path confusing.

## Credential-dependent setup

The Firebase Android configuration is bundled in `app/google-services.json`. Google authentication is therefore configured in the source; only the optional remote AI coach requires an external endpoint.

Android Studio normally creates `local.properties` with `sdk.dir`. Copy `local.properties.example` only if you want the optional AI coach endpoint or explicit version overrides. Firebase/Google configuration comes from the bundled `app/google-services.json`.

Google must remain enabled as a Firebase Authentication provider. The supplied Firebase Android client already references Prepwise package `com.nelsay.prepwise` and the SHA-1 used by the bundled update key. The app intentionally does not contain a fallback fake sign-in because the requested UX requires Google sign-in first.

## AI proxy

`coach-proxy/` contains a small Node/Express service. Set `OPENAI_API_KEY` on the server, optionally set `OPENAI_MODEL`, then deploy it behind HTTPS. The Android app only receives the proxy URL.

The coach endpoint returns explanations and citations restricted to the source URLs the app sends. The grade endpoint receives a verified rubric plus the learner response and produces a score/feedback. Timed quests do not award readiness credit if grading cannot be performed.

## Source policy / scientific QA

The app architecture separates:

1. **Verified course content** — stored in versioned assets with source IDs.
2. **Synthetic training data** — explicitly labeled as synthetic and used only for simulation/decision practice.
3. **AI explanation** — secondary, source-locked, and never promoted to the trusted curriculum automatically.

The initial curriculum is structured around the supplied certification roadmap and authoritative source families. Before calling the entire 124-lesson corpus publication-grade, perform a line-by-line scientific editorial QA against the linked references and add more primary/official references where a lesson needs narrower support. The source system is deliberately designed for that review rather than hiding uncertainty.

## Build

### Android Studio
Open the project, set the required values in `local.properties`, sync Gradle, and run the `app` configuration.

### GitHub Actions
Push `Prepwise-Android-source.zip` to the repository root and put the separate workflow at `.github/workflows/build-prepwise-from-zip.yml`. `COACH_ENDPOINT` is the only optional Android-build secret. Run **Build Prepwise Android from ZIP**. The workflow uploads a signed `Prepwise-signed-apk` artifact.

## Product identity

The Android product name is **Prepwise** and the package/application ID is permanently set in this build to `com.nelsay.prepwise`.

## Prepwise Firebase identity

- **App name:** Prepwise
- **Android package / application ID:** `com.nelsay.prepwise`
- **Update signing alias:** `prepwise-update`
- **Update keystore:** `signing/prepwise-update.jks`
- **Keystore password:** `android`
- **Key password:** `android`
- **SHA-1:** `8E:A8:1F:DF:A1:48:7C:C7:B2:FE:CE:1D:74:6B:9A:8A:A8:8E:01:AA`
- **SHA-256:** `EA:42:05:B9:AF:D3:79:6F:B8:EF:50:9A:A0:B6:95:FE:1A:39:F3:20:28:AC:D4:63:9A:CF:FE:73:81:E4:4E:C1`

Register both fingerprints on the Android app in Firebase before testing Google Sign-In.
The included key is deliberately the **fixed private Prepwise update key** for this personal APK workflow. Both debug and release APKs use it so future APKs can update an existing Prepwise install. Do not regenerate it. If this source is ever published or moved to the Play Store, migrate signing deliberately rather than exposing this key.

## Firebase rules

`firestore.rules` and `storage.rules` are included at the project root. They use a private-user ownership model: a signed-in user may access only data under `/users/{uid}/...`; everything else is denied.

## GitHub ZIP build

The source ZIP and workflow YAML are intentionally separate. Put `Prepwise-Android-source.zip` in the **repository root**. Put `build-prepwise-from-zip.yml` in **`.github/workflows/`**. The workflow extracts the ZIP, locates `settings.gradle.kts`, writes only optional runtime values, builds a **release APK signed with the bundled Prepwise update key**, and uploads `Prepwise-signed-apk`. Google/Firebase configuration is already bundled. `COACH_ENDPOINT` is optional.

## Firebase configuration now bundled

The Firebase configuration supplied for Prepwise is now stored at `app/google-services.json` using the canonical Firebase filename. The project applies the Google Services Gradle plugin, so Firebase Auth and `default_web_client_id` are generated from that file automatically. Firebase API/App/Project/Web-client secrets are no longer required as GitHub Actions secrets for the Android build. `COACH_ENDPOINT` remains optional for the AI coach proxy.

The bundled Firebase Android client is for package `com.nelsay.prepwise` and its registered Android OAuth certificate matches the fixed Prepwise update signing key.

## Seamless APK updates

Both debug and release variants are signed with `signing/prepwise-update.jks`. Do not delete, replace, or regenerate this keystore. A future Prepwise APK built from this source keeps the same package name and signing certificate, allowing Android to install it as an update over an earlier Prepwise APK signed with this same certificate.

Prepwise also uses a monotonic build-time `versionCode` based on epoch seconds unless `VERSION_CODE` is supplied explicitly. This prevents most normal future builds from being rejected as an older version.

## Build compatibility

Prepwise uses Kotlin 2.3.20 with Android Gradle Plugin 8.9.2 and Gradle 8.11.1. This combination is intentionally aligned with current Firebase Android Auth releases, which may contain Kotlin 2.3 metadata. Keep these versions aligned when upgrading Firebase.
