package com.nelsay.prepwise.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.nelsay.prepwise.BuildConfig
import com.nelsay.prepwise.data.Lesson
import com.nelsay.prepwise.data.SourceRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@Serializable
data class CoachPayload(
    val question: String,
    val mode: String,
    val lessonTitle: String,
    val verifiedContext: String,
    val sourceUrls: List<String>
)

@Serializable
data class CoachReply(val answer: String, val citations: List<String> = emptyList())

@Serializable
data class GradePayload(val response: String, val rubric: String, val task: String)

@Serializable
data class GradeReply(
    val score: Int,
    val feedback: String,
    val missing: List<String> = emptyList()
)

enum class AiProvider(val label: String) {
    OPENAI("OpenAI"), GEMINI("Gemini")
}

/**
 * API keys are encrypted at rest using an AES key held by Android Keystore.
 * Prepwise is a private/personal APK. If it is ever distributed publicly,
 * move provider calls behind a backend so client devices never hold API secrets.
 */
class SecureAiStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("prepwise_secure_ai", Context.MODE_PRIVATE)
    private val alias = "PrepwiseAiKey"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    fun put(name: String, value: String) {
        if (value.isBlank()) {
            prefs.edit().remove(name).apply()
            return
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encoded = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + "." +
            Base64.encodeToString(cipher.doFinal(value.toByteArray()), Base64.NO_WRAP)
        prefs.edit().putString(name, encoded).apply()
    }

    fun get(name: String): String {
        val raw = prefs.getString(name, null) ?: return ""
        return runCatching {
            val pieces = raw.split('.', limit = 2)
            require(pieces.size == 2)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                key(),
                GCMParameterSpec(128, Base64.decode(pieces[0], Base64.NO_WRAP))
            )
            String(cipher.doFinal(Base64.decode(pieces[1], Base64.NO_WRAP)))
        }.getOrDefault("")
    }
}

class CoachClient(context: Context) {
    private val appContext = context.applicationContext
    private val http = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }
    private val secureStore = SecureAiStore(appContext)
    private val prefs = appContext.getSharedPreferences("prepwise_ai_settings", Context.MODE_PRIVATE)

    var provider: AiProvider
        get() = runCatching {
            AiProvider.valueOf(prefs.getString("provider", "OPENAI") ?: "OPENAI")
        }.getOrDefault(AiProvider.OPENAI)
        set(value) = prefs.edit().putString("provider", value.name).apply()

    var openAiModel: String
        get() = prefs.getString("openai_model", "gpt-5.6-luna") ?: "gpt-5.6-luna"
        set(value) = prefs.edit().putString("openai_model", value.trim()).apply()

    var geminiModel: String
        get() = prefs.getString("gemini_model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        set(value) = prefs.edit().putString("gemini_model", value.trim()).apply()

    fun saveKey(provider: AiProvider, value: String) {
        secureStore.put(keyName(provider), value.trim())
    }

    fun removeKey(provider: AiProvider) = secureStore.put(keyName(provider), "")

    fun hasKey(provider: AiProvider = this.provider): Boolean = secureStore.get(keyName(provider)).isNotBlank()

    fun maskedStatus(provider: AiProvider): String = if (hasKey(provider)) "Saved securely" else "Not configured"

    private fun keyName(provider: AiProvider) = when (provider) {
        AiProvider.OPENAI -> "openai_key"
        AiProvider.GEMINI -> "gemini_key"
    }

    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(hasKey(provider)) { "Add a ${provider.label} API key first." }
            val raw = when (provider) {
                AiProvider.OPENAI -> openAi("Reply with PREPWISE_OK only.")
                AiProvider.GEMINI -> gemini("Reply with PREPWISE_OK only.")
            }
            if (!raw.contains("PREPWISE_OK", ignoreCase = true)) {
                "Connected to ${provider.label}; model responded successfully."
            } else {
                "Connected to ${provider.label}."
            }
        }
    }

    suspend fun grade(response: String, rubric: String, task: String): Result<GradeReply> = withContext(Dispatchers.IO) {
        runCatching {
            val providerPrompt = """
                You are Prepwise's scientific assessment grader.
                Grade only against the rubric and task below. Do not invent scientific facts that are absent from the rubric.
                Return ONLY one JSON object with exactly these fields:
                {"score":0,"feedback":"brief evidence-based feedback","missing":["missing point"]}
                Score must be an integer from 0 to 100.

                TASK:
                $task

                RUBRIC / VERIFIED ANSWER GUIDE:
                $rubric

                LEARNER RESPONSE:
                $response
            """.trimIndent()

            val raw = when {
                hasKey(provider) -> when (provider) {
                    AiProvider.OPENAI -> openAi(providerPrompt)
                    AiProvider.GEMINI -> gemini(providerPrompt)
                }
                BuildConfig.COACH_ENDPOINT.isNotBlank() -> proxyGrade(response, rubric, task)
                else -> error("AI grading is not configured. Add an OpenAI or Gemini API key in More → Settings.")
            }

            if (BuildConfig.COACH_ENDPOINT.isNotBlank() && !hasKey(provider)) {
                json.decodeFromString(GradeReply.serializer(), raw)
            } else {
                val parsed = extractJsonObject(raw)
                val obj = JSONObject(parsed)
                GradeReply(
                    score = obj.optInt("score", 0).coerceIn(0, 100),
                    feedback = obj.optString("feedback", "No feedback returned."),
                    missing = jsonArrayStrings(obj.optJSONArray("missing"))
                )
            }
        }
    }

    suspend fun ask(
        question: String,
        mode: String,
        lesson: Lesson?,
        sources: List<SourceRef>
    ): Result<CoachReply> = withContext(Dispatchers.IO) {
        runCatching {
            val verifiedContext = lesson?.let {
                buildString {
                    appendLine("LESSON: ${it.title}")
                    appendLine("START HERE: ${it.intro}")
                    appendLine("VERIFIED EXPLANATION: ${it.body}")
                    appendLine("WORKED EXAMPLE: ${it.workedExample}")
                    appendLine("PRACTICE: ${it.practicePrompt}")
                    appendLine("MASTERY: ${it.masteryPrompt}")
                }
            }.orEmpty()
            val sourceText = sources.joinToString("\n") { "- ${it.publisher}: ${it.title} (${it.url})" }
            val behavior = when (mode.lowercase()) {
                "tutor" -> "Explain clearly from basics, then build depth."
                "socratic" -> "Do not reveal the answer immediately. Ask one useful question at a time."
                "examiner" -> "Do not coach. Evaluate the learner's reasoning and ask a rigorous follow-up question."
                else -> "Give targeted hints and explain errors without doing all the work for the learner."
            }

            val prompt = """
                You are Prepwise, a side coach for Plant Ecology and Plant Physiology learners preparing for research-intensive MSc opportunities.
                SOURCE LOCK IS ON.
                You may use ONLY the VERIFIED COURSE CONTEXT below for scientific claims.
                The source URLs are provenance, not permission to invent facts you cannot see.
                If the supplied context does not support a scientific claim, say exactly: "I can't verify that from the approved Prepwise material yet."
                Never fabricate citations, measurements, papers, protocols, equations or biological mechanisms.
                $behavior

                Return ONLY JSON:
                {"answer":"your answer","used_source_urls":["url actually relevant to the supplied context"]}

                VERIFIED COURSE CONTEXT:
                $verifiedContext

                APPROVED SOURCE REFERENCES:
                $sourceText

                LEARNER:
                $question
            """.trimIndent()

            if (!hasKey(provider) && BuildConfig.COACH_ENDPOINT.isNotBlank()) {
                return@runCatching proxyAsk(question, mode, lesson, sources)
            }
            require(hasKey(provider)) {
                "${provider.label} is selected but its API key is not configured. Open More → Settings."
            }
            val raw = when (provider) {
                AiProvider.OPENAI -> openAi(prompt)
                AiProvider.GEMINI -> gemini(prompt)
            }
            val obj = runCatching { JSONObject(extractJsonObject(raw)) }.getOrNull()
            if (obj == null) {
                CoachReply(raw.trim(), emptyList())
            } else {
                CoachReply(
                    answer = obj.optString("answer", raw).trim(),
                    citations = jsonArrayStrings(obj.optJSONArray("used_source_urls"))
                        .filter { url -> sources.any { source -> source.url == url } }
                )
            }
        }
    }

    private fun openAi(prompt: String): String {
        val key = secureStore.get(keyName(AiProvider.OPENAI))
        require(key.isNotBlank()) { "OpenAI API key is missing." }
        val body = JSONObject()
            .put("model", openAiModel)
            .put("input", prompt)
            .put("reasoning", JSONObject().put("effort", "low"))

        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("OpenAI returned ${response.code}: ${text.take(500)}")
            val root = JSONObject(text)
            val direct = root.optString("output_text")
            if (direct.isNotBlank()) {
                direct
            } else {
                val output = root.optJSONArray("output") ?: JSONArray()
                val pieces = mutableListOf<String>()
                for (i in 0 until output.length()) {
                    val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val item = content.optJSONObject(j) ?: continue
                        item.optString("text").takeIf { it.isNotBlank() }?.let(pieces::add)
                    }
                }
                pieces.joinToString("\n").ifBlank { text }
            }
        }
    }

    private fun gemini(prompt: String): String {
        val key = secureStore.get(keyName(AiProvider.GEMINI))
        require(key.isNotBlank()) { "Gemini API key is missing." }
        val body = JSONObject().put(
            "contents",
            JSONArray().put(
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", prompt))
                )
            )
        )
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$geminiModel:generateContent")
            .addHeader("x-goog-api-key", key)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Gemini returned ${response.code}: ${text.take(500)}")
            val root = JSONObject(text)
            val candidates = root.optJSONArray("candidates")
            val parts = candidates?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
            if (parts == null) {
                text
            } else {
                buildList<String> {
                    for (i in 0 until parts.length()) {
                        parts.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }?.let(::add)
                    }
                }.joinToString("\n").ifBlank { text }
            }
        }
    }

    private fun proxyGrade(response: String, rubric: String, task: String): String {
        val payload = GradePayload(response, rubric, task)
        val request = Request.Builder()
            .url(BuildConfig.COACH_ENDPOINT.trimEnd('/') + "/grade")
            .post(json.encodeToString(GradePayload.serializer(), payload).toRequestBody("application/json".toMediaType()))
            .build()
        return http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) error("Grading server returned ${r.code}")
            r.body?.string().orEmpty()
        }
    }

    private fun proxyAsk(question: String, mode: String, lesson: Lesson?, sources: List<SourceRef>): CoachReply {
        val contextText = lesson?.let {
            "${it.intro}\n${it.body}\nWorked example: ${it.workedExample}\nPractice: ${it.practicePrompt}"
        }.orEmpty()
        val payload = CoachPayload(
            question,
            mode,
            lesson?.title ?: "General track coaching",
            contextText,
            sources.map { it.url }
        )
        val request = Request.Builder()
            .url(BuildConfig.COACH_ENDPOINT.trimEnd('/') + "/coach")
            .post(json.encodeToString(CoachPayload.serializer(), payload).toRequestBody("application/json".toMediaType()))
            .build()
        return http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) error("Coach server returned ${r.code}")
            json.decodeFromString(CoachReply.serializer(), r.body?.string().orEmpty())
        }
    }

    private fun extractJsonObject(text: String): String {
        val clean = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val start = clean.indexOf('{')
        val end = clean.lastIndexOf('}')
        return if (start >= 0 && end > start) clean.substring(start, end + 1) else clean
    }

    private fun jsonArrayStrings(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return buildList<String> {
            for (i in 0 until array.length()) {
                array.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }
}
