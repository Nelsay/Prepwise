package com.nelsay.prepwise.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.nelsay.prepwise.R

// Prepwise logo palette: deep navy + teal/emerald. Track colours are contextual only.
val PrepwiseTeal = Color(0xFF00A884)
val PrepwiseEmerald = Color(0xFF28C98B)
val PrepwiseAqua = Color(0xFF168AA0)
val PrepwiseNavy = Color(0xFF10223A)
val Eco = Color(0xFF2ECC8F)
val Plant = Color(0xFF9B8CFF)
val Gold = Color(0xFFF0B44D)

private val PureBlack = Color(0xFF000000)
private val PureWhite = Color(0xFFFFFFFF)
private val DarkSurface = Color(0xFF121212)
private val DarkRaised = Color(0xFF1C1C1E)
private val DarkRaised2 = Color(0xFF242426)
private val DarkMuted = Color(0xFFB8BDC7)
private val DarkOutline = Color(0xFF3A3A3C)

private val LightBackground = Color(0xFFF8FAF9)
private val LightSurface = Color(0xFFFFFFFF)
private val LightRaised = Color(0xFFF0F4F2)
private val LightInk = Color(0xFF101719)
private val LightMuted = Color(0xFF5D696D)
private val LightOutline = Color(0xFFD7DFDC)

enum class PrepwiseThemeMode(val label: String) {
    SYSTEM("System"), LIGHT("Light"), DARK("Dark")
}

enum class PrepwiseAccent(val label: String, val color: Color) {
    PREPWISE("Prepwise Teal", PrepwiseTeal),
    EMERALD("Emerald", PrepwiseEmerald),
    AQUA("Aqua", PrepwiseAqua),
    NAVY("Deep Navy", Color(0xFF315E86))
}

class ThemePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("prepwise_theme", Context.MODE_PRIVATE)

    // Dark is deliberately the default because Prepwise's current visual direction is a
    // Catalyst-like dark learning environment. Light/System remain available in Settings.
    var mode: PrepwiseThemeMode
        get() = runCatching {
            PrepwiseThemeMode.valueOf(prefs.getString("mode", "DARK") ?: "DARK")
        }.getOrDefault(PrepwiseThemeMode.DARK)
        set(value) = prefs.edit().putString("mode", value.name).apply()

    var accent: PrepwiseAccent
        get() = runCatching {
            PrepwiseAccent.valueOf(prefs.getString("accent", "PREPWISE") ?: "PREPWISE")
        }.getOrDefault(PrepwiseAccent.PREPWISE)
        set(value) = prefs.edit().putString("accent", value.name).apply()
}

private fun lightScheme(accent: Color) = lightColorScheme(
    primary = accent,
    onPrimary = if (accent == PrepwiseAccent.NAVY.color) PureWhite else Color(0xFF001E18),
    primaryContainer = Color(0xFFDDF7EF),
    onPrimaryContainer = Color(0xFF073F34),
    secondary = PrepwiseNavy,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFE7EDF3),
    onSecondaryContainer = PrepwiseNavy,
    tertiary = Color(0xFF6D55C8),
    onTertiary = PureWhite,
    tertiaryContainer = Color(0xFFECE8FF),
    onTertiaryContainer = Color(0xFF2C245D),
    background = LightBackground,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    surfaceVariant = LightRaised,
    onSurfaceVariant = LightMuted,
    outline = LightOutline,
    outlineVariant = Color(0xFFE8EEEB),
    error = Color(0xFFB3261E),
    onError = PureWhite
)

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = when (accent) {
        PrepwiseNavy -> Color(0xFF79B5E7)
        PrepwiseAccent.NAVY.color -> Color(0xFF79B5E7)
        else -> accent
    },
    // Dark text is deliberate on bright Prepwise accent fills for strong contrast.
    onPrimary = PureBlack,
    primaryContainer = Color(0xFF123C33),
    onPrimaryContainer = Color(0xFFD7FFF1),
    secondary = Color(0xFFBFD0E5),
    onSecondary = Color(0xFF132437),
    secondaryContainer = Color(0xFF203247),
    onSecondaryContainer = Color(0xFFEAF2FF),
    tertiary = Color(0xFFC9BFFF),
    onTertiary = Color(0xFF2D245D),
    tertiaryContainer = Color(0xFF3B326C),
    onTertiaryContainer = Color(0xFFF0ECFF),
    background = PureBlack,
    onBackground = PureWhite,
    surface = DarkSurface,
    onSurface = PureWhite,
    surfaceVariant = DarkRaised,
    onSurfaceVariant = DarkMuted,
    outline = DarkOutline,
    outlineVariant = DarkRaised2,
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF5D1F1A),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val GoogleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)

// Catalyst typography rule: Inter for headings/UI labels, Poppins for body copy.
private val InterFamily = FontFamily(
    Font(GoogleFont("Inter"), GoogleFontsProvider, FontWeight.Normal),
    Font(GoogleFont("Inter"), GoogleFontsProvider, FontWeight.Medium),
    Font(GoogleFont("Inter"), GoogleFontsProvider, FontWeight.SemiBold),
    Font(GoogleFont("Inter"), GoogleFontsProvider, FontWeight.Bold)
)

private val PoppinsFamily = FontFamily(
    Font(GoogleFont("Poppins"), GoogleFontsProvider, FontWeight.Normal),
    Font(GoogleFont("Poppins"), GoogleFontsProvider, FontWeight.Medium),
    Font(GoogleFont("Poppins"), GoogleFontsProvider, FontWeight.SemiBold),
    Font(GoogleFont("Poppins"), GoogleFontsProvider, FontWeight.Bold)
)

private val PrepwiseTypography = Typography(
    displayLarge = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.Bold, fontSize = 44.sp, lineHeight = 50.sp),
    displayMedium = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.Bold, fontSize = 37.sp, lineHeight = 43.sp),
    displaySmall = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineLarge = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 31.sp),
    headlineSmall = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp),
    titleLarge = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = PoppinsFamily, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 25.sp),
    bodyMedium = TextStyle(fontFamily = PoppinsFamily, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 23.sp),
    bodySmall = TextStyle(fontFamily = PoppinsFamily, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 19.sp),
    labelMedium = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 17.sp),
    labelSmall = TextStyle(fontFamily = InterFamily, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 15.sp)
)

@Composable
fun PrepwiseTheme(
    mode: PrepwiseThemeMode = PrepwiseThemeMode.DARK,
    accent: PrepwiseAccent = PrepwiseAccent.PREPWISE,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        PrepwiseThemeMode.SYSTEM -> isSystemInDarkTheme()
        PrepwiseThemeMode.LIGHT -> false
        PrepwiseThemeMode.DARK -> true
    }
    val colors = if (dark) darkScheme(accent.color) else lightScheme(accent.color)
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colors.background.toArgb()
            window.navigationBarColor = colors.background.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(colorScheme = colors, typography = PrepwiseTypography) {
        ProvideTextStyle(MaterialTheme.typography.bodyMedium) { content() }
    }
}
