package com.nelsay.prepwise.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Verified
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nelsay.prepwise.PrepwiseViewModel
import com.nelsay.prepwise.R
import com.nelsay.prepwise.ai.AiProvider
import com.nelsay.prepwise.data.Lesson
import com.nelsay.prepwise.data.Module
import com.nelsay.prepwise.data.Quest
import com.nelsay.prepwise.data.Simulation
import com.nelsay.prepwise.data.SourceRef
import com.nelsay.prepwise.ui.theme.Eco
import com.nelsay.prepwise.ui.theme.Gold
import com.nelsay.prepwise.ui.theme.Plant
import com.nelsay.prepwise.ui.theme.PrepwiseAccent
import com.nelsay.prepwise.ui.theme.PrepwiseThemeMode
import com.nelsay.prepwise.voice.SpeechInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val ScreenMaxWidth = 760.dp
private val ScreenHorizontal = 20.dp

@Composable
fun PrepwiseRoot(vm: PrepwiseViewModel) {
    when {
        vm.learner.signedInEmail.isBlank() -> SignIn(vm)
        vm.learner.trackId.isBlank() -> Setup(vm)
        else -> AppShell(vm)
    }
}

@Composable
private fun SignIn(vm: PrepwiseViewModel) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .padding(horizontal = 28.dp, vertical = 40.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            ImageBrandLogo(modifier = Modifier.width(210.dp).height(66.dp))
            Spacer(Modifier.height(48.dp))
            Eyebrow("SCIENTIFIC MASTERY")
            Spacer(Modifier.height(10.dp))
            Text(
                "Prepare to do the work, not just pass the course.",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(14.dp))
            Text(
                "Progressive plant-science learning, realistic research practice, timed decisions and evidence-based coaching—built to take you from foundations to certification readiness.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = vm::signIn,
                enabled = !vm.authBusy,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.AccountCircle, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text(if (vm.authBusy) "Signing in…" else "Continue with Google")
            }
            vm.authError?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "After sign-in, choose your research path and study commitment. You can Fast Track material you can already prove.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun Setup(vm: PrepwiseViewModel) {
    var track by remember { mutableStateOf("") }
    var commitment by remember { mutableIntStateOf(30) }

    FocusColumn {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ImageBrandLogo(modifier = Modifier.width(148.dp).height(44.dp))
            Spacer(Modifier.weight(1f))
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(
                    "SETUP",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(34.dp))
        Eyebrow("WELCOME ${vm.learner.displayName.ifBlank { "BACK" }.uppercase()}")
        Spacer(Modifier.height(8.dp))
        Text("Choose your research path", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(10.dp))
        Text(
            "This determines your lessons, simulations, timed quests and final readiness evidence. Each path starts from the basics, then grows into research-level application.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))

        PathChoice(
            id = "ecology",
            title = "Plant Ecology",
            desc = "Vegetation science, field methods, populations, communities, restoration, R, GIS and spatial reasoning.",
            color = Eco,
            selected = track,
            on = { track = it }
        )
        Spacer(Modifier.height(10.dp))
        PathChoice(
            id = "physiology",
            title = "Plant Physiology",
            desc = "Water relations, photosynthesis, nutrition, stress physiology, experimentation, R, genomics and functional analysis.",
            color = Plant,
            selected = track,
            on = { track = it }
        )

        AnimatedVisibility(track.isNotBlank()) {
            Column {
                Spacer(Modifier.height(32.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(Modifier.height(28.dp))
                Eyebrow("YOUR COMMITMENT")
                Spacer(Modifier.height(8.dp))
                Text("Choose a daily study rhythm", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pick a pace you can sustain. The app uses this to keep sessions focused rather than dumping the full curriculum on you at once.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(15, 30, 45, 60)) { minutes ->
                        FilterChip(
                            selected = commitment == minutes,
                            onClick = { commitment = minutes },
                            label = { Text("$minutes min") }
                        )
                    }
                }
                Spacer(Modifier.height(28.dp))
                Button(
                    onClick = { vm.finishSetup(track, commitment) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Enter Prepwise")
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
    }
}

@Composable
private fun PathChoice(
    id: String,
    title: String,
    desc: String,
    color: Color,
    selected: String,
    on: (String) -> Unit
) {
    val isSelected = selected == id
    Surface(
        onClick = { on(id) },
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) color else MaterialTheme.colorScheme.outline
        )
    ) {
        Row(
            Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) color else MaterialTheme.colorScheme.outline)
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(10.dp))
            Icon(
                if (isSelected) Icons.Default.CheckCircle else Icons.Default.ChevronRight,
                contentDescription = null,
                tint = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

enum class Tab(val label: String) { Path("Path"), Lab("Lab"), Quests("Quests"), Progress("Progress"), More("More") }

@Composable
private fun AppShell(vm: PrepwiseViewModel) {
    var tab by remember { mutableStateOf(Tab.Path) }
    var lesson by remember { mutableStateOf<Lesson?>(null) }
    var sim by remember { mutableStateOf<Simulation?>(null) }
    var quest by remember { mutableStateOf<Quest?>(null) }
    var fast by remember { mutableStateOf<Module?>(null) }
    var showCoach by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    if (lesson != null) {
        LessonView(vm, lesson!!) { lesson = null }
        return
    }
    if (sim != null) {
        SimulationRunner(vm, sim!!) { sim = null }
        return
    }
    if (quest != null) {
        QuestRunner(vm, quest!!) { quest = null }
        return
    }
    if (fast != null) {
        FastTrackRunner(
            vm = vm,
            m = fast!!,
            onPass = { vm.fastTrack(fast!!); fast = null },
            onBack = { fast = null }
        )
        return
    }
    if (showCoach) {
        CoachScreen(vm) { showCoach = false }
        return
    }
    if (showSettings) {
        SettingsScreen(vm) { showSettings = false }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = {
                                Icon(
                                    when (t) {
                                        Tab.Path -> Icons.Default.Route
                                        Tab.Lab -> Icons.Default.Science
                                        Tab.Quests -> Icons.Default.Timer
                                        Tab.Progress -> Icons.Default.Insights
                                        Tab.More -> Icons.Default.Settings
                                    },
                                    contentDescription = null
                                )
                            },
                            label = { Text(t.label, style = MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            Crossfade(targetState = tab, label = "prepwise-tabs") { selected ->
                when (selected) {
                    Tab.Path -> PathScreen(vm, { lesson = it }, { fast = it })
                    Tab.Lab -> LabScreen(vm) { sim = it }
                    Tab.Quests -> QuestList(vm) { quest = it }
                    Tab.Progress -> ProgressScreen(vm)
                    Tab.More -> MoreScreen(vm, onCoach = { showCoach = true }, onSettings = { showSettings = true })
                }
            }
        }
    }
}

@Composable
private fun PathScreen(vm: PrepwiseViewModel, onLesson: (Lesson) -> Unit, onFast: (Module) -> Unit) {
    val track = vm.repo.curriculum.tracks.first { it.id == vm.learner.trackId }
    val lessons = track.modules.flatMap { it.lessons }
    val total = lessons.size
    val done = lessons.count { it.id in vm.learner.completedLessons }
    val pct = if (total == 0) 0 else done * 100 / total
    val nextLesson = lessons.firstOrNull { it.id !in vm.learner.completedLessons }
    val currentModule = track.modules.firstOrNull { module -> module.lessons.any { it.id !in vm.learner.completedLessons } }
        ?: track.modules.lastOrNull()
    val simValues = vm.repo.simulations.filter { it.trackId == track.id }.mapNotNull { vm.learner.simulationScores[it.id] }
    val questValues = vm.repo.quests.filter { it.trackId == track.id }.mapNotNull { vm.learner.questScores[it.id] }
    val simAvg = if (simValues.isEmpty()) 0 else simValues.average().toInt()
    val questAvg = if (questValues.isEmpty()) 0 else questValues.average().toInt()

    ScreenList(spacing = 18.dp) {
        item {
            ScreenHeader(
                vm = vm,
                title = "Your path",
                sub = "One clear next step at a time. Prove what you know, then move forward."
            )
        }
        item {
            FocusHero(
                eyebrow = "CONTINUE",
                title = nextLesson?.title ?: "Path complete",
                meta = if (nextLesson != null) "${nextLesson.estimatedMinutes} min • ${currentModule?.title.orEmpty()}" else "Review your readiness evidence",
                progress = pct,
                buttonLabel = if (nextLesson != null) "Continue lesson" else "Review progress",
                onClick = { nextLesson?.let(onLesson) }
            )
        }
        item {
            StatStrip(
                values = listOf(
                    Triple("Mastery", "$pct%", "$done/$total lessons"),
                    Triple("Lab", "$simAvg%", "best evidence"),
                    Triple("Quests", "$questAvg%", "under pressure")
                )
            )
        }
        item {
            SectionLead("Learning path", "Modules open progressively. The current module stays expanded; completed work gets out of your way.")
        }
        items(track.modules, key = { it.id }) { module ->
            ModuleTimeline(
                vm = vm,
                m = module,
                isCurrent = module.id == currentModule?.id,
                onLesson = onLesson,
                onFast = onFast
            )
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
}

@Composable
private fun ModuleTimeline(
    vm: PrepwiseViewModel,
    m: Module,
    isCurrent: Boolean,
    onLesson: (Lesson) -> Unit,
    onFast: (Module) -> Unit
) {
    val completed = m.lessons.count { it.id in vm.learner.completedLessons }
    val isDone = completed == m.lessons.size
    var open by remember(m.id, isCurrent) { mutableStateOf(isCurrent) }
    val dotColor = when {
        isDone -> Eco
        isCurrent -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outline
    }

    Row(
        Modifier.fillMaxWidth().height(IntrinsicSize.Min),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.width(28.dp).fillMaxHeight()) {
            Box(
                Modifier
                    .width(2.dp)
                    .fillMaxHeight()
                    .align(Alignment.TopCenter)
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )
            Surface(
                modifier = Modifier.size(14.dp).align(Alignment.TopCenter),
                shape = CircleShape,
                color = dotColor,
                border = if (isDone || isCurrent) null else BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
            ) {}
        }
        Spacer(Modifier.width(10.dp))
        Column(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(if (open) MaterialTheme.colorScheme.surface else Color.Transparent)
                .animateContentSize()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open }
                    .padding(horizontal = if (open) 16.dp else 0.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${m.number.toString().padStart(2, '0')}  ${m.title}",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isCurrent) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        when {
                            isDone -> "Mastered"
                            isCurrent -> "$completed/${m.lessons.size} mastered • Current module"
                            else -> "$completed/${m.lessons.size} mastered"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isDone) Eco else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(open) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    Spacer(Modifier.height(12.dp))
                    Text(m.overview, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { onFast(m) }, contentPadding = PaddingValues(0.dp)) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Fast Track • prove I know this")
                    }
                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    m.lessons.forEachIndexed { index, lesson ->
                        LessonRow(
                            lesson = lesson,
                            completed = lesson.id in vm.learner.completedLessons,
                            onClick = { onLesson(lesson) }
                        )
                        if (index != m.lessons.lastIndex) {
                            HorizontalDivider(
                                modifier = Modifier.padding(start = 34.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonRow(lesson: Lesson, completed: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(24.dp),
            shape = CircleShape,
            color = if (completed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    if (completed) Icons.Default.Check else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp),
                    tint = if (completed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(lesson.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                "${lesson.estimatedMinutes} min • basics → application → proof",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LessonView(vm: PrepwiseViewModel, l: Lesson, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val track = vm.repo.curriculum.tracks.first { it.id == vm.learner.trackId }
    val module = track.modules.first { it.lessons.any { lesson -> lesson.id == l.id } }
    val lessonIndex = module.lessons.indexOfFirst { it.id == l.id }
    val sources = l.sourceIds.mapNotNull { vm.repo.sources[it] }
    var answer by remember { mutableStateOf("") }
    var showSources by remember { mutableStateOf(false) }

    FocusColumn(topPadding = 10.dp) {
        BackBar(label = "Path", onBack = onBack)
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Eyebrow("${module.number.toString().padStart(2, '0')} • ${module.title.uppercase()}")
            Spacer(Modifier.weight(1f))
            Text(
                "${lessonIndex + 1}/${module.lessons.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(l.title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            MetaBadge("${l.estimatedMinutes} min")
            MetaBadge("Verified", verified = true)
        }
        Spacer(Modifier.height(26.dp))

        LessonTextSection("Start here", l.intro)
        LessonTextSection("Build the concept", l.body)

        InsetPanel(
            eyebrow = "WORKED RESEARCH EXAMPLE",
            text = l.workedExample,
            icon = Icons.Default.Science
        )
        Spacer(Modifier.height(28.dp))

        Text("Practice it", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(l.practicePrompt, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = answer,
            onValueChange = { answer = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 5,
            shape = RoundedCornerShape(16.dp),
            label = { Text("Explain your reasoning") }
        )
        Spacer(Modifier.height(10.dp))
        VoiceButton(onText = { answer = it })
        Spacer(Modifier.height(30.dp))

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Column(Modifier.padding(18.dp)) {
                Eyebrow("MASTERY GATE", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                Text(l.masteryPrompt, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { vm.completeLesson(l.id) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Mark mastery demonstrated")
                }
            }
        }
        Spacer(Modifier.height(24.dp))

        Surface(
            onClick = { showSources = !showSources },
            color = Color.Transparent,
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Sources & evidence", style = MaterialTheme.typography.titleSmall)
                    Text("${sources.size} approved references", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(if (showSources) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
            }
        }
        AnimatedVisibility(showSources) {
            Column {
                sources.forEach { source ->
                    SourceRow(source) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url))) }
                }
                l.videoUrl?.let { url ->
                    TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }) {
                        Icon(Icons.Default.SmartDisplay, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("Open vetted video / training resource")
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun LabScreen(vm: PrepwiseViewModel, onSim: (Simulation) -> Unit) {
    val sims = vm.repo.simulations.filter { it.trackId == vm.learner.trackId }
    val next = sims.firstOrNull { vm.learner.simulationScores[it.id] == null }

    ScreenList(spacing = 18.dp) {
        item { ScreenHeader(vm, "Simulation lab", "Make the decisions a researcher would make, then work with the consequences.") }
        next?.let { simulation ->
            item {
                FocusHero(
                    eyebrow = "NEXT LAB",
                    title = simulation.title,
                    meta = simulation.setting,
                    progress = vm.learner.simulationScores[simulation.id] ?: 0,
                    buttonLabel = "Enter simulation",
                    onClick = { onSim(simulation) }
                )
            }
        }
        item { SectionLead("All simulations", "Synthetic training data, realistic research logic and decision-based scoring.") }
        items(sims, key = { it.id }) { simulation ->
            SimpleDestinationRow(
                icon = Icons.Default.Science,
                title = simulation.title,
                meta = simulation.setting,
                trailing = vm.learner.simulationScores[simulation.id]?.let { "$it%" } ?: "Ready",
                onClick = { onSim(simulation) }
            )
        }
    }
}

@Composable
private fun SimulationRunner(vm: PrepwiseViewModel, s: Simulation, onBack: () -> Unit) {
    val answers = remember { mutableStateMapOf<Int, Int>() }
    var decisionIndex by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<Int?>(null) }
    var showData by remember { mutableStateOf(true) }
    val current = s.decisions.getOrNull(decisionIndex)

    FocusColumn(topPadding = 10.dp) {
        BackBar(label = "Lab", onBack = onBack)
        Spacer(Modifier.height(14.dp))
        Eyebrow("REAL-WORLD SIMULATION")
        Spacer(Modifier.height(8.dp))
        Text(s.title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(18.dp))
        LessonTextSection("Setting", s.setting, compact = true)
        LessonTextSection("Mission", s.mission, compact = true)

        Surface(
            onClick = { showData = !showData },
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Insights, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Field / instrument data", style = MaterialTheme.typography.titleSmall)
                        Text("Tap to ${if (showData) "hide" else "inspect"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(if (showData) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                }
                AnimatedVisibility(showData) {
                    Column {
                        Spacer(Modifier.height(14.dp))
                        DataTable(s.data)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))

        if (result == null && current != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Decision ${decisionIndex + 1} of ${s.decisions.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                Text("${((decisionIndex + 1) * 100 / s.decisions.size)}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = (decisionIndex + 1f) / s.decisions.size,
                modifier = Modifier.fillMaxWidth().height(4.dp),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(22.dp))
            Text(current.prompt, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(14.dp))
            current.options.forEachIndexed { optionIndex, option ->
                SelectableOption(
                    text = option,
                    selected = answers[decisionIndex] == optionIndex,
                    onClick = { answers[decisionIndex] = optionIndex }
                )
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (decisionIndex > 0) {
                    OutlinedButton(onClick = { decisionIndex-- }, modifier = Modifier.weight(1f).height(52.dp)) {
                        Text("Previous")
                    }
                }
                Button(
                    onClick = {
                        if (decisionIndex < s.decisions.lastIndex) {
                            decisionIndex++
                        } else {
                            val correct = s.decisions.indices.count { answers[it] == s.decisions[it].correct }
                            result = correct * 100 / s.decisions.size
                            vm.scoreSimulation(s.id, result!!)
                        }
                    },
                    enabled = answers[decisionIndex] != null,
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (decisionIndex == s.decisions.lastIndex) "Submit" else "Next decision")
                }
            }
        }

        result?.let { score ->
            ResultHero(score = score, label = "Simulation score")
            Spacer(Modifier.height(24.dp))
            LessonTextSection("Debrief", s.debrief)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun QuestList(vm: PrepwiseViewModel, onQuest: (Quest) -> Unit) {
    val quests = vm.repo.quests.filter { it.trackId == vm.learner.trackId }
    val next = quests.firstOrNull { vm.learner.questScores[it.id] == null }

    ScreenList(spacing = 18.dp) {
        item { ScreenHeader(vm, "Timed quests", "Apply science under pressure. These are compact research decisions, not trivia streaks.") }
        next?.let { quest ->
            item {
                FocusHero(
                    eyebrow = "NEXT QUEST • ${quest.minutes} MIN",
                    title = quest.title,
                    meta = quest.difficulty,
                    progress = vm.learner.questScores[quest.id] ?: 0,
                    buttonLabel = "Open quest",
                    onClick = { onQuest(quest) }
                )
            }
        }
        item { SectionLead("Quest bank", "Short, focused scenarios that expose whether you can apply the science without unlimited time.") }
        items(quests, key = { it.id }) { quest ->
            SimpleDestinationRow(
                icon = Icons.Default.Timer,
                title = quest.title,
                meta = "${quest.minutes} min • ${quest.difficulty}",
                trailing = vm.learner.questScores[quest.id]?.let { "$it%" } ?: "Ready",
                onClick = { onQuest(quest) }
            )
        }
    }
}

@Composable
private fun QuestRunner(vm: PrepwiseViewModel, q: Quest, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val grader = vm.ai
    var remaining by remember { mutableIntStateOf(q.minutes * 60) }
    var started by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    var score by remember { mutableStateOf<Int?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(started) {
        while (started && remaining > 0) {
            delay(1000)
            remaining--
        }
    }

    FocusColumn(topPadding = 10.dp) {
        BackBar(label = "Quests", onBack = onBack)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Eyebrow("TIMED QUEST")
            Spacer(Modifier.weight(1f))
            Surface(shape = RoundedCornerShape(12.dp), color = if (remaining < 60) MaterialTheme.colorScheme.error.copy(alpha = .12f) else MaterialTheme.colorScheme.surfaceVariant) {
                Text(
                    String.format("%02d:%02d", remaining / 60, remaining % 60),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (remaining < 60) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(q.title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))

        if (!started && score == null) {
            LessonTextSection("Brief", q.brief)
            Text("Deliverables", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            q.tasks.forEachIndexed { index, task ->
                Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                    Text("${index + 1}.", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(task, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { started = true },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Timer, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Start ${q.minutes}-minute quest")
            }
        } else if (score == null) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Text(q.brief, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 8,
                shape = RoundedCornerShape(16.dp),
                label = { Text("Your response") }
            )
            Spacer(Modifier.height(10.dp))
            VoiceButton(onText = { answer = it })
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    started = false
                    busy = true
                    scope.launch {
                        grader.grade(answer, q.answerGuide, q.brief + " Deliverables: " + q.tasks.joinToString())
                            .onSuccess {
                                score = it.score.coerceIn(0, 100)
                                feedback = it.feedback + if (it.missing.isNotEmpty()) "\nMissing: " + it.missing.joinToString() else ""
                                vm.scoreQuest(q.id, score!!)
                            }
                            .onFailure { feedback = it.message.orEmpty() }
                        busy = false
                    }
                },
                enabled = answer.length > 40 && !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(15.dp)
            ) {
                Text(if (busy) "Grading against verified rubric…" else "Finish & grade")
            }
        }

        score?.let { result ->
            ResultHero(score = result, label = "Quest score")
            if (feedback.isNotBlank()) {
                Spacer(Modifier.height(24.dp))
                LessonTextSection("Rubric feedback", feedback)
            }
            Spacer(Modifier.height(12.dp))
            LessonTextSection("Verified answer guide", q.answerGuide)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FastTrackRunner(
    vm: PrepwiseViewModel,
    m: Module,
    onPass: () -> Unit,
    onBack: () -> Unit
) {
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf(false) }
    val lessons = m.lessons
    val current = lessons.getOrNull(idx)
    val options = remember(idx) { lessons.shuffled() }

    FocusColumn(topPadding = 10.dp) {
        BackBar(label = "Path", onBack = onBack)
        Spacer(Modifier.height(12.dp))
        Eyebrow("FAST TRACK")
        Spacer(Modifier.height(8.dp))
        Text(m.title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(10.dp))
        Text(
            "This is a transfer test, not a shortcut button. Recognize the concept in unfamiliar research situations to skip material you can already prove.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(22.dp))

        if (!done && current != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Scenario ${idx + 1} of ${lessons.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                Text("100% required", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = (idx + 1f) / lessons.size,
                modifier = Modifier.fillMaxWidth().height(4.dp),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(22.dp))
            Text(current.workedExample, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(20.dp))
            Text("Which concept does this scenario test?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            options.forEach { option ->
                OutlinedButton(
                    onClick = {
                        if (option.id == current.id) score++
                        idx++
                        if (idx >= lessons.size) done = true
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(option.title, modifier = Modifier.fillMaxWidth())
                }
            }
        } else {
            val passed = score == lessons.size
            ResultHero(score = score * 100 / lessons.size.coerceAtLeast(1), label = if (passed) "Fast Track passed" else "Fast Track result")
            Spacer(Modifier.height(18.dp))
            Text(
                if (passed) "You demonstrated every concept across the transfer scenarios. This module can be marked mastered."
                else "The result exposed useful gaps. Return to the module and learn only what you could not yet transfer independently.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))
            if (passed) {
                Button(onClick = onPass, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp)) {
                    Text("Mark module mastered")
                }
            } else {
                Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp)) {
                    Text("Return to lessons")
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(vm: PrepwiseViewModel) {
    val track = vm.repo.curriculum.tracks.first { it.id == vm.learner.trackId }
    val lessons = track.modules.flatMap { it.lessons }
    val lPct = vm.learner.completedLessons.count { id -> lessons.any { it.id == id } } * 100 / lessons.size.coerceAtLeast(1)
    val sims = vm.repo.simulations.filter { it.trackId == track.id }
    val simPct = if (sims.isEmpty()) 0 else sims.map { vm.learner.simulationScores[it.id] ?: 0 }.average().toInt()
    val quests = vm.repo.quests.filter { it.trackId == track.id }
    val qPct = if (quests.isEmpty()) 0 else quests.map { vm.learner.questScores[it.id] ?: 0 }.average().toInt()
    val readiness = (lPct * .60 + simPct * .25 + qPct * .15).toInt()
    var showSources by remember { mutableStateOf(false) }

    ScreenList(spacing = 18.dp) {
        item { ScreenHeader(vm, "Readiness", "A single evidence view: course mastery, realistic practice and timed performance.") }
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(readiness, size = 112.dp)
                    Spacer(Modifier.width(20.dp))
                    Column(Modifier.weight(1f)) {
                        Eyebrow(if (readiness >= 85) "READY FOR CERTIFICATION" else "CERTIFICATION READINESS", color = if (readiness >= 85) Eco else Gold)
                        Spacer(Modifier.height(7.dp))
                        Text(
                            if (readiness >= 85) "Your evidence meets Prepwise's internal readiness threshold."
                            else "Build toward 85% with strong simulation and timed performance—not page completion alone.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        item {
            StatStrip(
                values = listOf(
                    Triple("Course", "$lPct%", "mastery"),
                    Triple("Lab", "$simPct%", "performance"),
                    Triple("Timed", "$qPct%", "pressure")
                )
            )
        }
        item {
            SectionLead("Evidence, not activity", "Prepwise counts what you can demonstrate. Fast Track, lab decisions and timed work are treated as evidence of competence.")
        }
        item {
            Surface(
                onClick = { showSources = !showSources },
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Source Lock", style = MaterialTheme.typography.titleMedium)
                            Text("Approved publishers behind the trusted curriculum layer", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(if (showSources) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                    }
                    AnimatedVisibility(showSources) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            vm.repo.sources.values.forEach { source ->
                                Text(
                                    "✓ ${source.publisher} — ${source.title}",
                                    modifier = Modifier.padding(vertical = 5.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
}

@Composable
private fun MoreScreen(
    vm: PrepwiseViewModel,
    onCoach: () -> Unit,
    onSettings: () -> Unit
) {
    ScreenList(spacing = 18.dp) {
        item { ScreenHeader(vm, "More", "Coach, appearance, AI engines and account controls stay outside the learning route.") }
        item {
            SimpleDestinationRow(
                icon = Icons.Default.Mic,
                title = "Side coach",
                meta = "Tutor, Coach, Socratic and Examiner modes with Source Lock.",
                trailing = vm.ai.provider.label,
                onClick = onCoach
            )
        }
        item {
            SimpleDestinationRow(
                icon = Icons.Default.Settings,
                title = "Settings",
                meta = "Theme, Prepwise accent colours, OpenAI / Gemini, account and log out.",
                trailing = "Open",
                onClick = onSettings
            )
        }
        item {
            Spacer(Modifier.height(8.dp))
            Eyebrow("ACCOUNT", color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(vm.learner.displayName.ifBlank { "Prepwise learner" }, style = MaterialTheme.typography.titleLarge)
            Text(vm.learner.signedInEmail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
}

@Composable
private fun SettingsScreen(vm: PrepwiseViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ai = vm.ai
    var provider by remember { mutableStateOf(ai.provider) }
    var apiKey by remember { mutableStateOf("") }
    var model by remember {
        mutableStateOf(if (provider == AiProvider.OPENAI) ai.openAiModel else ai.geminiModel)
    }
    var status by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var keyRevision by remember { mutableIntStateOf(0) }

    ScreenList(spacing = 18.dp) {
        item { BackBar(label = "More", onBack = onBack) }
        item {
            Column {
                Eyebrow("SETTINGS", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(7.dp))
                Text("Make Prepwise yours", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(7.dp))
                Text(
                    "One visual system across the whole app. Theme changes apply to lessons, simulations, quests, progress and coach screens—not just the dashboard.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(8.dp))
            SectionLead("Appearance", "Catalyst-style restrained surfaces with Prepwise logo colours as the accent system.")
        }
        item {
            Text("Theme", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(PrepwiseThemeMode.entries) { mode ->
                    FilterChip(
                        selected = vm.themeMode == mode,
                        onClick = { vm.updateThemeMode(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }
        item {
            Text("Accent colour", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                PrepwiseAccent.entries.forEach { choice ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            onClick = { vm.updateAccent(choice) },
                            modifier = Modifier.size(44.dp),
                            shape = CircleShape,
                            color = choice.color,
                            border = BorderStroke(
                                if (vm.accent == choice) 3.dp else 1.dp,
                                if (vm.accent == choice) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            if (vm.accent == choice) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = if (choice == PrepwiseAccent.NAVY) Color.White else Color(0xFF001E18),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(choice.label.substringBefore(' '), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(8.dp))
            SectionLead(
                "AI provider",
                "Choose OpenAI or Gemini. Keys are encrypted on this device with Android Keystore and never placed in the APK source."
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(AiProvider.entries) { option ->
                    FilterChip(
                        selected = provider == option,
                        onClick = {
                            provider = option
                            ai.provider = option
                            model = if (option == AiProvider.OPENAI) ai.openAiModel else ai.geminiModel
                            apiKey = ""
                            status = ""
                        },
                        label = { Text(option.label) }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "${provider.label}: ${ai.maskedStatus(provider)}",
                style = MaterialTheme.typography.labelMedium,
                color = if (ai.hasKey(provider)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it; status = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("${provider.label} API key") },
                placeholder = { Text(if (ai.hasKey(provider)) "Paste only to replace saved key" else "Paste API key") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; status = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Model") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    ai.provider = provider
                    if (apiKey.isNotBlank()) ai.saveKey(provider, apiKey)
                    if (provider == AiProvider.OPENAI) ai.openAiModel = model else ai.geminiModel = model
                    apiKey = ""
                    keyRevision++
                    status = "Saved."
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Save AI settings") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    scope.launch {
                        testing = true
                        status = ""
                        ai.provider = provider
                        if (provider == AiProvider.OPENAI) ai.openAiModel = model else ai.geminiModel = model
                        ai.testConnection()
                            .onSuccess { status = it }
                            .onFailure { status = it.message ?: "Connection test failed." }
                        testing = false
                    }
                },
                enabled = !testing && ai.hasKey(provider),
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text(if (testing) "Testing…" else "Test connection") }
            if (ai.hasKey(provider)) {
                TextButton(
                    onClick = {
                        ai.removeKey(provider)
                        keyRevision++
                        status = "${provider.label} key removed."
                    }
                ) { Text("Remove saved ${provider.label} key") }
            }
            if (status.isNotBlank()) {
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (status.contains("Connected") || status == "Saved.") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Read the revision so key-status-dependent controls recompose after a save/removal.
            if (keyRevision < 0) Text("")
        }
        item {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Source Lock remains on regardless of provider. AI is a coach, not the scientific source of truth; unsupported claims must be refused rather than invented.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(8.dp))
            SectionLead("Account", "Your learning route stays on this device when you log out, so signing back in does not reset progress.")
        }
        item {
            SimpleDestinationRow(
                icon = Icons.Default.AccountCircle,
                title = vm.learner.displayName.ifBlank { "Signed-in learner" },
                meta = vm.learner.signedInEmail,
                trailing = "Google",
                onClick = { }
            )
        }
        item {
            OutlinedButton(
                onClick = vm::logout,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Log out")
            }
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
}

@Composable
private fun CoachScreen(vm: PrepwiseViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val client = vm.ai
    var mode by remember { mutableStateOf("Coach") }
    var question by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    ScreenList(spacing = 18.dp) {
        item { BackBar(label = "More", onBack = onBack) }
        item { ScreenHeader(vm, "Side coach", "Ask, speak, debug or defend. The coach is constrained by the verified learning context.") }
        item {
            Text(
                "${client.provider.label} • ${client.maskedStatus(client.provider)}",
                style = MaterialTheme.typography.labelMedium,
                color = if (client.hasKey(client.provider)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Tutor", "Coach", "Socratic", "Examiner")) { item ->
                    FilterChip(selected = mode == item, onClick = { mode = item }, label = { Text(item) })
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Source Lock is on. If the approved lesson and source context cannot support a scientific claim, the coach is instructed to say it cannot verify it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
        item {
            OutlinedTextField(
                value = question,
                onValueChange = { question = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 6,
                shape = RoundedCornerShape(18.dp),
                label = { Text("Ask a question or answer aloud") }
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { VoiceButton(onText = { question = it; vm.addViva() }, fill = true) }
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val track = vm.repo.curriculum.tracks.first { it.id == vm.learner.trackId }
                            val current = track.modules.flatMap { it.lessons }.firstOrNull { it.id !in vm.learner.completedLessons }
                                ?: track.modules.last().lessons.last()
                            val sources = current.sourceIds.mapNotNull { vm.repo.sources[it] }
                            client.ask(question, mode, current, sources)
                                .onSuccess { reply = it.answer + if (it.citations.isNotEmpty()) "\n\nSources: ${it.citations.joinToString()}" else "" }
                                .onFailure { reply = it.message.orEmpty() }
                            busy = false
                        }
                    },
                    enabled = question.isNotBlank() && !busy,
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (busy) "Checking…" else "Ask coach")
                }
            }
        }
        if (reply.isNotBlank()) {
            item {
                SectionLead("Coach response", reply)
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ---------- Shared presentation components ----------

@Composable
private fun ImageBrandLogo(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Image(
        painter = painterResource(R.drawable.prepwise_logo),
        contentDescription = "Prepwise",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
private fun FocusColumn(
    topPadding: androidx.compose.ui.unit.Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .widthIn(max = ScreenMaxWidth)
                .align(Alignment.TopCenter)
                .verticalScroll(rememberScrollState())
                .padding(start = ScreenHorizontal, end = ScreenHorizontal, top = topPadding, bottom = 32.dp),
            content = content
        )
    }
}

@Composable
private fun ScreenList(
    spacing: androidx.compose.ui.unit.Dp = 14.dp,
    content: LazyListScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .widthIn(max = ScreenMaxWidth)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(start = ScreenHorizontal, end = ScreenHorizontal, top = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(spacing),
            content = content
        )
    }
}

@Composable
private fun ScreenHeader(vm: PrepwiseViewModel, title: String, sub: String) {
    val track = vm.repo.curriculum.tracks.first { it.id == vm.learner.trackId }
    val trackColor = if (track.id == "ecology") Eco else Plant
    Column {
        Eyebrow(track.name.uppercase(), color = trackColor)
        Spacer(Modifier.height(7.dp))
        Text(title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(7.dp))
        Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionLead(title: String, text: String) {
    Column {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FocusHero(
    eyebrow: String,
    title: String,
    meta: String,
    progress: Int,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(20.dp)) {
            Eyebrow(eyebrow, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(9.dp))
            Text(title, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(7.dp))
            Text(meta, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(
                progress = progress.coerceIn(0, 100) / 100f,
                modifier = Modifier.fillMaxWidth().height(5.dp),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(buttonLabel)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.ChevronRight, contentDescription = null)
            }
        }
    }
}

@Composable
private fun StatStrip(values: List<Triple<String, String, String>>) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp)) {
            values.forEachIndexed { index, value ->
                Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    Text(value.first, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(3.dp))
                    Text(value.second, style = MaterialTheme.typography.titleLarge)
                    Text(value.third, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
                if (index != values.lastIndex) {
                    Box(Modifier.width(1.dp).height(48.dp).background(MaterialTheme.colorScheme.outline))
                }
            }
        }
    }
}

@Composable
private fun SimpleDestinationRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    meta: String,
    trailing: String,
    onClick: () -> Unit
) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(modifier = Modifier.size(38.dp), shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(trailing, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun BackBar(label: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
        }
        Spacer(Modifier.width(2.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Eyebrow(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = color)
}

@Composable
private fun MetaBadge(text: String, verified: Boolean = false) {
    Surface(
        shape = CircleShape,
        color = if (verified) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (verified) {
                Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(4.dp))
            }
            Text(text, style = MaterialTheme.typography.labelSmall, color = if (verified) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LessonTextSection(title: String, text: String, compact: Boolean = false) {
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(if (compact) 6.dp else 9.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Spacer(Modifier.height(if (compact) 20.dp else 28.dp))
}

@Composable
private fun InsetPanel(
    eyebrow: String,
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(8.dp))
                Eyebrow(eyebrow, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(10.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SourceRow(source: SourceRef, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(source.publisher, style = MaterialTheme.typography.labelMedium)
            Text(source.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SelectableOption(text: String, selected: Boolean, onClick: () -> Unit) {
    val fill = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val foreground = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = fill,
        border = BorderStroke(
            if (selected) 1.5.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        )
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = foreground,
                    unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = foreground,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun DataTable(data: List<List<String>>) {
    if (data.isEmpty()) return
    Column(Modifier.fillMaxWidth()) {
        data.forEachIndexed { rowIndex, row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (rowIndex == 0) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .padding(vertical = 8.dp, horizontal = 6.dp)
            ) {
                row.forEach { cell ->
                    Text(
                        cell,
                        modifier = Modifier.weight(1f),
                        style = if (rowIndex == 0) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodySmall,
                        color = if (rowIndex == 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            if (rowIndex != data.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }
    }
}

@Composable
private fun ResultHero(score: Int, label: String) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(score, size = 88.dp)
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Eyebrow(label.uppercase(), color = if (score >= 80) Eco else Gold)
                Spacer(Modifier.height(6.dp))
                Text(if (score >= 80) "Strong evidence" else "Keep building", style = MaterialTheme.typography.headlineSmall)
                Text(
                    if (score >= 80) "You handled this task at a strong level." else "Use the feedback to strengthen the weak points before retrying.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ProgressRing(value: Int, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress = value.coerceIn(0, 100) / 100f,
            modifier = Modifier.fillMaxSize(),
            color = if (value >= 85) Eco else MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeWidth = 7.dp
        )
        Text("$value%", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun VoiceButton(onText: (String) -> Unit, fill: Boolean = false) {
    val context = LocalContext.current
    val speech = remember { SpeechInput(context) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            speech.start(onText) { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
        }
    }
    FilledTonalButton(
        onClick = { permission.launch(Manifest.permission.RECORD_AUDIO) },
        modifier = if (fill) Modifier.fillMaxWidth().height(52.dp) else Modifier.wrapContentHeight(),
        shape = RoundedCornerShape(14.dp)
    ) {
        Icon(Icons.Default.Mic, contentDescription = null)
        Spacer(Modifier.width(7.dp))
        Text("Speak")
    }
}
