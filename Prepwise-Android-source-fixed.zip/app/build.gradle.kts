import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.gms.google-services")
}

val local = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use(::load)
}

fun cfg(name: String): String =
    (local.getProperty(name) ?: System.getenv(name) ?: "")
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")

// A later build should install over an earlier Prepwise APK without uninstalling.
// Epoch seconds stay monotonic for normal builds and remain within Android's Int
// versionCode range until 2038. VERSION_CODE can still be explicitly overridden.
val autoVersionCode = (System.currentTimeMillis() / 1000L).toInt()
val prepwiseVersionCode = local.getProperty("VERSION_CODE")?.toIntOrNull()
    ?: System.getenv("VERSION_CODE")?.toIntOrNull()
    ?: autoVersionCode

android {
    namespace = "com.nelsay.prepwise"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nelsay.prepwise"
        minSdk = 26
        targetSdk = 35
        versionCode = prepwiseVersionCode
        versionName = local.getProperty("VERSION_NAME")
            ?: System.getenv("VERSION_NAME")
            ?: "1.0.$prepwiseVersionCode"

        buildConfigField("String", "COACH_ENDPOINT", "\"${cfg("COACH_ENDPOINT")}\"")
    }

    signingConfigs {
        create("prepwiseUpdate") {
            // IMPORTANT: Every Prepwise APK intended to update an existing install
            // must keep using this exact keystore/certificate.
            storeFile = rootProject.file("signing/prepwise-update.jks")
            storePassword = "android"
            keyAlias = "prepwise-update"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("prepwiseUpdate")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("prepwiseUpdate")
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.ui:ui-text-google-fonts")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.datastore:datastore-preferences:1.1.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    implementation(platform("com.google.firebase:firebase-bom:34.18.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}
